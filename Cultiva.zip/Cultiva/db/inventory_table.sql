-- Create inventory table for CULTIVA café
-- Run this SQL in phpMyAdmin or MySQL CLI

USE cultiva_db;

DROP TABLE IF EXISTS inventory;

CREATE TABLE IF NOT EXISTS inventory (
  id INT AUTO_INCREMENT PRIMARY KEY,
  item_name VARCHAR(255) NOT NULL,
  type VARCHAR(100) NOT NULL DEFAULT 'other',
  current_stock INT NOT NULL DEFAULT 0,
  reorder_level INT NOT NULL DEFAULT 10,
  unit_price DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
  supplier VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX (item_name),
  INDEX (type),
  INDEX (current_stock)
) ENGINE=InnoDB DEFAULT CHARSET = utf8mb4;

-- Insert sample inventory items with categories
INSERT INTO inventory (item_name, type, current_stock, reorder_level, unit_price, supplier) VALUES
('Arabica Coffee Beans', 'beverages', 50, 20, 500.00, 'Local Roasters Co.'),
('Espresso Machine Parts', 'utensils', 15, 5, 2000.00, 'Coffee Equipment Ltd.'),
('Milk (1L)', 'beverages', 100, 30, 80.00, 'Fresh Dairy Supplies'),
('Sugar (1kg)', 'condiments', 40, 15, 150.00, 'Food Wholesale Inc.'),
('Cups (100pcs)', 'utensils', 500, 100, 200.00, 'Packaging Plus'),
('Napkins (500pcs)', 'utensils', 20, 5, 300.00, 'Packaging Plus'),
('Vanilla Syrup', 'condiments', 25, 10, 400.00, 'Flavor Suppliers Ltd.'),
('Caramel Syrup', 'condiments', 22, 10, 400.00, 'Flavor Suppliers Ltd.'),
('Croissant', 'pastries', 30, 5, 80.00, 'Local Bakery'),
('Cappuccino Powder', 'beverages', 15, 10, 350.00, 'Coffee Supplier');
