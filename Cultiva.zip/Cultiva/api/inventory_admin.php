<?php
// Simple Inventory admin page
// NOTE: This is a lightweight admin for local/dev usage. Do NOT expose it publicly
// without authentication. It uses `db.php` for DB connection and supports add/edit/delete.

@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
@error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

require_once __DIR__ . '/db.php';

function respond_and_exit($msg) {
    echo '<p>' . htmlspecialchars($msg) . '</p>';
    echo '<p><a href="' . htmlspecialchars($_SERVER['PHP_SELF']) . '">Back</a></p>';
    exit;
}

// Handle POST actions: add, update, delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add') {
        $item_name = trim($_POST['item_name'] ?? '');
        $type = trim(strtolower($_POST['type'] ?? ''));
        $current_stock = intval($_POST['current_stock'] ?? 0);
        $reorder_level = intval($_POST['reorder_level'] ?? 0);
        $unit_price = floatval($_POST['unit_price'] ?? 0);
        $supplier = trim($_POST['supplier'] ?? '');

        if ($item_name === '') respond_and_exit('Item name is required');

        $stmt = $conn->prepare("INSERT INTO inventory (item_name, type, current_stock, reorder_level, unit_price, supplier) VALUES (?, ?, ?, ?, ?, ?)");
        if (!$stmt) respond_and_exit('Prepare failed: ' . $conn->error);
        $stmt->bind_param('ssiids', $item_name, $type, $current_stock, $reorder_level, $unit_price, $supplier);
        if (!$stmt->execute()) respond_and_exit('Execute failed: ' . $stmt->error);
        $stmt->close();
        header('Location: ' . $_SERVER['PHP_SELF']); exit;
    }
    if ($action === 'update') {
        $id = intval($_POST['id'] ?? 0);
        if (!$id) respond_and_exit('Missing id');
        $item_name = trim($_POST['item_name'] ?? '');
        $type = trim(strtolower($_POST['type'] ?? ''));
        $current_stock = intval($_POST['current_stock'] ?? 0);
        $reorder_level = intval($_POST['reorder_level'] ?? 0);
        $unit_price = floatval($_POST['unit_price'] ?? 0);
        $supplier = trim($_POST['supplier'] ?? '');

        $stmt = $conn->prepare("UPDATE inventory SET item_name=?, type=?, current_stock=?, reorder_level=?, unit_price=?, supplier=? WHERE id=?");
        if (!$stmt) respond_and_exit('Prepare failed: ' . $conn->error);
        $stmt->bind_param('ssiidsi', $item_name, $type, $current_stock, $reorder_level, $unit_price, $supplier, $id);
        if (!$stmt->execute()) respond_and_exit('Execute failed: ' . $stmt->error);
        $stmt->close();
        header('Location: ' . $_SERVER['PHP_SELF']); exit;
    }
    if ($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        if (!$id) respond_and_exit('Missing id');
        $stmt = $conn->prepare("DELETE FROM inventory WHERE id = ?");
        if (!$stmt) respond_and_exit('Prepare failed: ' . $conn->error);
        $stmt->bind_param('i', $id);
        if (!$stmt->execute()) respond_and_exit('Execute failed: ' . $stmt->error);
        $stmt->close();
        header('Location: ' . $_SERVER['PHP_SELF']); exit;
    }
}

// Fetch items for listing
$items = [];
$res = $conn->query("SELECT id, item_name, type, current_stock, reorder_level, unit_price, supplier FROM inventory ORDER BY item_name ASC");
if ($res) {
    while ($r = $res->fetch_assoc()) $items[] = $r;
}

// If editing, load the item
$editing = null;
if (isset($_GET['edit'])) {
    $editId = intval($_GET['edit']);
    if ($editId) {
        $stmt = $conn->prepare('SELECT id, item_name, type, current_stock, reorder_level, unit_price, supplier FROM inventory WHERE id = ?');
        if ($stmt) {
            $stmt->bind_param('i', $editId);
            $stmt->execute();
            $res = $stmt->get_result();
            $editing = $res->fetch_assoc();
            $stmt->close();
        }
    }
}

?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Inventory Admin</title>
    <style>
        body{font-family:Arial,Helvetica,sans-serif;padding:18px}
        table{border-collapse:collapse;width:100%;margin-bottom:18px}
        th,td{border:1px solid #ddd;padding:8px}
        th{background:#f4f4f4}
        form.inline{display:inline}
        .btn{padding:6px 10px;border-radius:4px;border:1px solid #888;background:#eee;cursor:pointer}
        .btn-danger{background:#fdd}
    </style>
</head>
<body>
    <h2>Inventory Admin</h2>
    <p>This page lists inventory items and allows adding, editing, and deleting. For local/dev use only.</p>

    <h3><?php echo $editing ? 'Edit Item' : 'Add Item'; ?></h3>
    <form method="post">
        <input type="hidden" name="action" value="<?php echo $editing ? 'update' : 'add'; ?>">
        <?php if ($editing): ?><input type="hidden" name="id" value="<?php echo (int)$editing['id']; ?>"><?php endif; ?>
        <label>Item Name<br><input name="item_name" required value="<?php echo htmlspecialchars($editing['item_name'] ?? ''); ?>" style="width:400px"></label><br>
        <label>Type<br><input name="type" value="<?php echo htmlspecialchars($editing['type'] ?? ''); ?>" placeholder="ingredient|packaging|other"></label><br>
        <label>Current Stock<br><input name="current_stock" type="number" min="0" value="<?php echo htmlspecialchars($editing['current_stock'] ?? 0); ?>"></label><br>
        <label>Reorder Level<br><input name="reorder_level" type="number" min="0" value="<?php echo htmlspecialchars($editing['reorder_level'] ?? 0); ?>"></label><br>
        <label>Unit Price<br><input name="unit_price" type="number" step="0.01" value="<?php echo htmlspecialchars($editing['unit_price'] ?? 0); ?>"></label><br>
        <label>Supplier<br><input name="supplier" value="<?php echo htmlspecialchars($editing['supplier'] ?? ''); ?>"></label><br><br>
        <button class="btn" type="submit"><?php echo $editing ? 'Update' : 'Add'; ?></button>
        <?php if ($editing): ?><a href="<?php echo $_SERVER['PHP_SELF']; ?>">Cancel</a><?php endif; ?>
    </form>

    <h3>Items (<?php echo count($items); ?>)</h3>
    <table>
        <thead><tr><th>ID</th><th>Name</th><th>Type</th><th>Stock</th><th>Reorder</th><th>Price</th><th>Supplier</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach($items as $it): ?>
            <tr>
                <td><?php echo (int)$it['id']; ?></td>
                <td><?php echo htmlspecialchars($it['item_name']); ?></td>
                <td><?php echo htmlspecialchars($it['type']); ?></td>
                <td><?php echo (int)$it['current_stock']; ?></td>
                <td><?php echo (int)$it['reorder_level']; ?></td>
                <td><?php echo htmlspecialchars($it['unit_price']); ?></td>
                <td><?php echo htmlspecialchars($it['supplier']); ?></td>
                <td>
                    <a class="btn" href="?edit=<?php echo (int)$it['id']; ?>">Edit</a>
                    <form class="inline" method="post" onsubmit="return confirm('Delete this item?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?php echo (int)$it['id']; ?>">
                        <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <p><a href="../dashboard/admin.html">Open Dashboard UI</a> | <a href="<?php echo basename(__FILE__); ?>">Refresh</a></p>
</body>
</html>
