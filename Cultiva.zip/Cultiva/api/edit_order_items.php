<?php
if (!ob_get_level()) ob_start();
function respond($payload, $code = 200){
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    ob_clean();
    http_response_code($code);
    echo json_encode($payload);
    exit;
}
include "db.php";

$data = json_decode(file_get_contents("php://input"), true);
$code = isset($data["code"]) ? $data["code"] : null;
$items = isset($data["items"]) ? $data["items"] : [];

if (!$code) respond(["status"=>"error","message"=>"Missing code"], 400);

// get order ID
$stmt = $conn->prepare("SELECT id FROM orders WHERE code = ?");
if (!$stmt) respond(["status"=>"error","message"=>"Prepare failed: " . $conn->error], 500);
$stmt->bind_param('s', $code);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows === 0) {
    $stmt->close();
    respond(["status"=>"error","message"=>"Order not found"], 404);
}
$order = $res->fetch_assoc();
$order_id = $order["id"];
$stmt->close();

// clear the old items
 $del = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
 if (!$del) respond(["status"=>"error","message"=>"Prepare failed: " . $conn->error], 500);
 $del->bind_param('i', $order_id);
 $del->execute();
 $del->close();

// reinsert new items with prepared statement
 $ins = $conn->prepare("INSERT INTO order_items (order_id, item_name, qty, price) VALUES (?, ?, ?, ?)");
 if (!$ins) respond(["status"=>"error","message"=>"Prepare failed: " . $conn->error], 500);

 foreach ($items as $i) {
    $name = $i["name"] ?? '';
    $qty = isset($i["qty"]) ? intval($i["qty"]) : 1;
    $price = isset($i["price"]) ? intval($i["price"]) : 0;
    $ins->bind_param('isii', $order_id, $name, $qty, $price);
    $ins->execute();
 }
 $ins->close();

respond(["status" => "success", "message" => "Items updated"]);

