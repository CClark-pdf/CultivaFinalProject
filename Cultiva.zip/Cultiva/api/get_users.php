<?php
// Prevent PHP from emitting HTML error pages; prefer JSON responses
@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
@error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

// Defensive JSON responder
if (!ob_get_level()) ob_start();
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST");
function respond($payload, $code = 200){
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    ob_clean();
    http_response_code($code);
    echo json_encode($payload);
    exit;
}

include "db.php";

// Return list of users (id, name, email, role)
$res = $conn->query("SELECT id, name, email, role, created_at FROM users ORDER BY id DESC");
if (!$res) {
    respond(["status" => "error", "message" => "Query failed: " . $conn->error], 500);
}

$rows = [];
while ($r = $res->fetch_assoc()) {
    $rows[] = $r;
}

respond(["status" => "success", "data" => $rows]);
