<?php
if (!ob_get_level()) ob_start();
function respond($payload, $code = 200){
	if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
	ob_clean();
	http_response_code($code);
	echo json_encode($payload);
	exit;
}
include "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$code = isset($data["code"]) ? $data["code"] : null;
$status = isset($data["status"]) ? $data["status"] : null;
// Validate input
if (empty($code) || empty($status)) {
	respond(["status" => "error", "message" => "Missing code or status"], 400);
}

// Update using prepared statement to avoid SQL injection
$stmt = $conn->prepare("UPDATE orders SET status = ? WHERE code = ?");
if ($stmt) {
	$stmt->bind_param('ss', $status, $code);
	$ok = $stmt->execute();
	if ($ok) {
		respond(["status" => "success", "message" => "Order status updated"]);
	} else {
		$stmt->close();
		respond(["status" => "error", "message" => "Failed to update order"], 500);
	}
	$stmt->close();
} else {
	respond(["status" => "error", "message" => "Failed to prepare statement"], 500);
}
?>
