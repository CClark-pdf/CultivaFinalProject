<?php
if (!ob_get_level()) ob_start();
header('Content-Type: application/json; charset=utf-8');
function respond($payload, $code = 200){
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    ob_clean();
    http_response_code($code);
    echo json_encode($payload);
    exit;
}
include "db.php";

try {
    // Reset all inventory stock to 0
    $query = "UPDATE inventory SET current_stock = 0";
    
    if ($conn->query($query)) {
        // Get count of updated items
        $countQuery = "SELECT COUNT(*) as total FROM inventory";
        $result = $conn->query($countQuery);
        $row = $result->fetch_assoc();
        $total = $row['total'];
        
        respond([
            "status" => "success",
            "message" => "All inventory stock reset to 0",
            "items_updated" => $total
        ]);
    } else {
        throw new Exception("Failed to reset inventory: " . $conn->error);
    }
    
} catch (Exception $e) {
    respond([
        "status" => "error",
        "message" => $e->getMessage()
    ], 500);
}
?>
