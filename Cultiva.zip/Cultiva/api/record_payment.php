<?php
if (!ob_get_level()) ob_start();
function respond($payload, $code = 200){
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    ob_clean();
    http_response_code($code);
    echo json_encode($payload);
    exit;
}
include "db.php";

// Read JSON body
$data = json_decode(file_get_contents('php://input'), true);
if (!$data || !isset($data['code']) || !isset($data['amount'])) {
    respond(['status'=>'error','message'=>'Missing code or amount'], 400);
}

$code = $data['code'];
$amount = floatval($data['amount']);

// Find order id
$stmt = $conn->prepare("SELECT id FROM orders WHERE code = ? LIMIT 1");
if (!$stmt) {
    respond(['status'=>'error','message'=>'DB prepare failed'], 500);
}
$stmt->bind_param('s', $code);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows === 0) {
    $stmt->close();
    respond(['status'=>'error','message'=>'Order not found'], 404);
}
$row = $res->fetch_assoc();
$order_id = intval($row['id']);
$stmt->close();

// Compute total for the order
$q = $conn->prepare("SELECT SUM(qty * price) AS total FROM order_items WHERE order_id = ?");
if (!$q) respond(['status'=>'error','message'=>'DB prepare failed'], 500);
$q->bind_param('i', $order_id);
$q->execute();
$r = $q->get_result();
$total = 0;
if ($r && $r->num_rows > 0) {
    $trow = $r->fetch_assoc();
    $total = floatval($trow['total']);
}
$q->close();

// Validate amount
$change = round($amount - $total, 2);
if ($amount < $total) {
    respond(['status'=>'error','message'=>'Insufficient amount','short'=>$total - $amount], 400);
}

// Ensure payments table exists
$create = "CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    amount_paid DECIMAL(10,2) NOT NULL,
    change_amount DECIMAL(10,2) NOT NULL,
    paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$conn->query($create);

// Insert payment
$ins = $conn->prepare("INSERT INTO payments (order_id, amount_paid, change_amount) VALUES (?, ?, ?)");
if (!$ins) {
    respond(['status'=>'error','message'=>'Prepare insert failed'], 500);
}
$ins->bind_param('idd', $order_id, $amount, $change);
if (!$ins->execute()) {
    $ins->close();
    respond(['status'=>'error','message'=>'Failed to record payment'], 500);
}
$ins->close();

// Update order status to completed
$u = $conn->prepare("UPDATE orders SET status = 'completed' WHERE id = ?");
if ($u) {
    $u->bind_param('i', $order_id);
    $u->execute();
    $u->close();
}

respond(['status'=>'success','order_id'=>$order_id,'total'=>$total,'amount_paid'=>$amount,'change'=>$change]);
?>
