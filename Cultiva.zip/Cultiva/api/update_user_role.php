<?php
if (!ob_get_level()) ob_start();
function respond($payload, $code = 200){
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    ob_clean();
    http_response_code($code);
    echo json_encode($payload);
    exit;
}
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST");

include "db.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(["status" => "error", "message" => "Only POST allowed"], 405);
}

$data = json_decode(file_get_contents('php://input'), true);
if (!isset($data['id']) || !isset($data['role'])) {
    respond(["status" => "error", "message" => "Missing id or role"], 400);
}

 $id = intval($data['id']);
 $role = trim($data['role']);
 // normalize role to lowercase for consistency
 $role = strtolower($role);
 $allowed = ['admin','cashier','customer'];
if (!in_array($role, $allowed)) {
    respond(["status" => "error", "message" => "Invalid role"], 400);
}

$stmt = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
if (!$stmt) {
    respond(["status" => "error", "message" => "Prepare failed: " . $conn->error], 500);
}
$stmt->bind_param('si', $role, $id);
if (!$stmt->execute()) {
    $stmt->close();
    respond(["status" => "error", "message" => "Execute failed: " . $stmt->error], 500);
}
$stmt->close();

respond(["status" => "success", "message" => "Role updated"]);
?>