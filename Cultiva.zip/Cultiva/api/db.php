<?php
// Database connection
// Behavior:
// - Read credentials from environment variables if available (recommended for hosting)
// - Otherwise fall back to the provided InfinityFree credentials so the site is ready for deployment

// Production (InfinityFree) defaults (provided by user)
$prod_host = 'sql112.infinityfree.com';
$prod_user = 'if0_40597167';
$prod_pass = 'QYCT0JOLgL';
$prod_db   = 'if0_40597167_cultiva_db';
// Allow overriding via common env var names
$host   = getenv('DB_HOST') ?: getenv('MYSQL_HOST') ?: $prod_host;
$user   = getenv('DB_USER') ?: getenv('MYSQL_USER') ?: $prod_user;
$pass   = getenv('DB_PASS') ?: getenv('MYSQL_PASS') ?: $prod_pass;
$dbname = getenv('DB_NAME') ?: getenv('MYSQL_DB') ?: $prod_db;

// create connection (mysqli)
 $conn = new mysqli($host, $user, $pass, $dbname);

// set utf8 charset
if ($conn && ! $conn->connect_error) {
    $conn->set_charset('utf8mb4');
}

// If connection fails, return a JSON error and stop execution to avoid sending non-JSON output
if ($conn->connect_error) {
    if (!ob_get_level()) ob_start();
    // Ensure JSON header (some callers may already set it, but set it defensively)
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    ob_clean();
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    // exit to prevent further PHP output (avoid plain-text die())
    exit;
}

// Note: no closing PHP tag to avoid accidental trailing whitespace output
