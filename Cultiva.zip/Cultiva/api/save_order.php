<?php
// Temporary debug logging to help diagnose production 500 / HTML responses.
$DEBUG_LOG = true; // set to false to disable logging
if (!function_exists('respond')) {
    if (!ob_get_level()) ob_start();
    function respond($payload, $code = 200){
        if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
        // avoid wiping debug logs
        // do not call ob_clean() here when debugging
        http_response_code($code);
        echo json_encode($payload);
        exit;
    }
}

if ($DEBUG_LOG) {
    try {
        $logfile = __DIR__ . '/debug_save_order.log';
        $entry = "\n=== " . date('Y-m-d H:i:s') . " ===\n";
        $entry .= "REMOTE_ADDR=" . ($_SERVER['REMOTE_ADDR'] ?? 'cli') . "\n";
        $entry .= "REQUEST_METHOD=" . ($_SERVER['REQUEST_METHOD'] ?? '') . "\n";
        $entry .= "RAW_POST=" . file_get_contents('php://input') . "\n";
        if (!empty($_POST)) $entry .= "_POST=" . json_encode($_POST) . "\n";
        file_put_contents($logfile, $entry, FILE_APPEND | LOCK_EX);
    } catch (Exception $e) {
        // ignore logging errors
    }
}

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST");

include "db.php";

// save_order endpoint

// Validate input
if (!isset($_POST["code"]) || !isset($_POST["items"])) {
    respond(["status"=>"error","message"=>"Missing fields"], 400);
}

$code = $_POST["code"];
$items = json_decode($_POST["items"], true);
$order_status = isset($_POST["status"]) ? $_POST["status"] : "pending"; // Default to pending - cashier will collect payment

if (!is_array($items)) {
    respond(["status"=>"error","message"=>"Invalid items JSON"], 400);
}

// Insert into orders table
 $stmt = $conn->prepare("INSERT INTO orders (code, status) VALUES (?, ?)");
 if (!$stmt) {
     respond(["status"=>"error","message"=>"DB prepare failed: " . $conn->error], 500);
 }
 $stmt->bind_param("ss", $code, $order_status);
 if (!$stmt->execute()) {
     $err = $stmt->error;
     $stmt->close();
     respond(["status"=>"error","message"=>"DB execute failed: " . $err], 500);
 }
 $order_id = $conn->insert_id; // get inserted id from connection
 $stmt->close();

// Insert each item into order_items
 $item_stmt = $conn->prepare("INSERT INTO order_items (order_id, item_name, qty, price) VALUES (?, ?, ?, ?)");
 if (!$item_stmt) {
     respond(["status"=>"error","message"=>"Prepare order_items failed: " . $conn->error], 500);
 }

 $failed = [];
 foreach ($items as $idx => $item) {
    if (!is_array($item) || !isset($item['name'])) {
        $failed[] = [ 'index' => $idx, 'message' => 'Invalid item format' ];
        continue;
    }

    $name = (string)$item["name"];
    $qty  = isset($item["qty"]) ? intval($item["qty"]) : 1;
    $price = isset($item["price"]) ? intval($item["price"]) : 0;

    if (!$item_stmt->bind_param("isii", $order_id, $name, $qty, $price)) {
        $failed[] = [ 'index' => $idx, 'message' => 'bind_param failed', 'error' => $item_stmt->error ];
        continue;
    }

    if (!$item_stmt->execute()) {
        $failed[] = [ 'index' => $idx, 'message' => 'execute failed', 'error' => $item_stmt->error ];
    }
 }

 $item_stmt->close();

 if (count($failed) > 0) {
     respond(["status"=>"error","message"=>"Some items failed to insert","details"=>$failed, "order_id"=>$order_id], 500);
 }
respond(["status"=>"success","order_id"=>$order_id]);
?>
