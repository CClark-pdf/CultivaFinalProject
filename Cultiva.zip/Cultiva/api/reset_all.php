<?php
if (!ob_get_level()) ob_start();
header("Access-Control-Allow-Origin: *");
header('Content-Type: application/json; charset=utf-8');
function respond($payload, $code = 200){
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    ob_clean();
    http_response_code($code);
    echo json_encode($payload);
    exit;
}

include "db.php";

// Get the request body
$input = json_decode(file_get_contents('php://input'), true);

// Verify user role is admin
if (!isset($input['user_role']) || $input['user_role'] !== 'admin') {
    respond(["status" => "error", "message" => "Only admins can reset data"], 403);
}

try {
    // Delete all orders and order items
    if (!$conn->query("DELETE FROM order_items")) {
        throw new Exception("Failed to delete order items: " . $conn->error);
    }
    if (!$conn->query("DELETE FROM orders")) {
        throw new Exception("Failed to delete orders: " . $conn->error);
    }
    
    // Reset inventory to 0
    if (!$conn->query("UPDATE inventory SET current_stock = 0")) {
        throw new Exception("Failed to reset inventory: " . $conn->error);
    }
    
    respond([
        "status" => "success",
        "message" => "All data has been reset successfully"
    ]);
} catch (Exception $e) {
    respond([
        "status" => "error",
        "message" => "Reset failed: " . $e->getMessage()
    ], 500);
}
?>


