<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST");
header('Content-Type: application/json; charset=utf-8');

// Start output buffering to prevent accidental non-JSON output (warnings/whitespace)
if (!ob_get_level()) ob_start();

function respond_json($payload) {
    // Clear any buffered output to avoid corrupting JSON
    if (ob_get_length() !== false) {
        @ob_end_clean();
        ob_start();
    }
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload);
    exit;
}

include "db.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond_json(["status" => "error", "message" => "Only POST allowed"]);
}

$data = json_decode(file_get_contents("php://input"), true);

// Validate input
if (!isset($data['email']) || !isset($data['password'])) {
    respond_json(["status" => "error", "message" => "Missing email or password"]);
}

$email = trim($data['email']);
$password = trim($data['password']);
// Query user by email and get stored password hash
$stmt = $conn->prepare("SELECT id, name, email, role, password FROM users WHERE email = ?");
if (!$stmt) {
    respond_json(["status" => "error", "message" => "Query failed: " . $conn->error]);
}

$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $stmt->close();
    respond_json(["status" => "error", "message" => "Invalid email or password"]);
}

$user = $result->fetch_assoc();
$stmt->close();

$storedHash = $user['password'];

// First try password_verify (works for password_hash)
$passwordValid = false;

if (password_verify($password, $storedHash)) {
    $passwordValid = true;
} else {
    // Fallback for legacy MD5 hashes: if stored hash equals md5(password), rehash to modern algorithm
    if ($storedHash === md5($password)) {
        $passwordValid = true;
        // Re-hash password with password_hash and update DB
        $newHash = password_hash($password, PASSWORD_DEFAULT);
        $upd = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        if ($upd) {
            $upd->bind_param("si", $newHash, $user['id']);
            $upd->execute();
            $upd->close();
        }
    }
}

// Check if password is valid
if (!$passwordValid) {
    respond_json(["status" => "error", "message" => "Invalid email or password"]);
}

// Successful login
respond_json([
    "status" => "success",
    "message" => "Login successful",
    "user" => [
        "id" => $user['id'],
        "name" => $user['name'],
        "email" => $user['email'],
        "role" => $user['role']
    ]
]);
?>
