<?php
if (!ob_get_level()) ob_start();
function respond($payload, $code = 200){
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    ob_clean();
    http_response_code($code);
    echo json_encode($payload);
    exit;
}
header("Access-Control-Allow-Origin: *");
include "db.php";

if (!$conn) {
    respond(["status" => "error", "message" => "Database connection failed"], 500);
}

// Get top ordered items from completed orders
$query = "
    SELECT i.item_name, SUM(i.qty) as total_qty
    FROM order_items i
    JOIN orders o ON i.order_id = o.id
    WHERE o.status = 'completed'
    GROUP BY i.item_name
    ORDER BY total_qty DESC
    LIMIT 10
";

$res = $conn->query($query);

if (!$res) {
    respond(["status" => "error", "message" => "Query failed: " . $conn->error], 500);
}

$items = [];
while ($row = $res->fetch_assoc()) {
    $items[] = [
        "name" => $row["item_name"],
        "qty" => intval($row["total_qty"])
    ];
}

respond(["status" => "success", "data" => $items]);

