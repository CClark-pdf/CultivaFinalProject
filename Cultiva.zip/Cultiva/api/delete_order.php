<?php
if (!ob_get_level()) ob_start();
function respond($payload, $code = 200){
	if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
	ob_clean();
	http_response_code($code);
	echo json_encode($payload);
	exit;
}
include "db.php";
$code = isset($_GET["code"]) ? $_GET["code"] : null;
if (!$code) respond(["status"=>"error","message"=>"Missing code"], 400);

$stmt = $conn->prepare("DELETE FROM orders WHERE code = ?");
if (!$stmt) respond(["status"=>"error","message"=>"Prepare failed: " . $conn->error], 500);
$stmt->bind_param('s', $code);
if (!$stmt->execute()){
	$stmt->close();
	respond(["status"=>"error","message"=>"Execute failed: " . $stmt->error], 500);
}
$stmt->close();
respond(["status" => "success"]);

