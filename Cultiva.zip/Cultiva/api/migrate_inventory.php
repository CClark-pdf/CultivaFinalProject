<?php
if (!ob_get_level()) ob_start();
function respond($payload, $code = 200){
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    ob_clean();
    http_response_code($code);
    echo json_encode($payload);
    exit;
}

// Database migration script - adds 'type' column to inventory table
// Run this once to update existing database

include "db.php";

try {
    // Check if 'type' column exists
    $checkQuery = "SHOW COLUMNS FROM inventory LIKE 'type'";
    $result = $conn->query($checkQuery);
    
    if ($result && $result->num_rows > 0) {
        // Column already exists
        respond(["status" => "info", "message" => "Type column already exists"]);
    }
    
    // Add 'type' column
    $addColumnQuery = "ALTER TABLE inventory ADD COLUMN type VARCHAR(100) NOT NULL DEFAULT 'other' AFTER item_name";
    
    if (!$conn->query($addColumnQuery)) {
        throw new Exception("Failed to add type column: " . $conn->error);
    }
    
    // Add index on type column
    $addIndexQuery = "ALTER TABLE inventory ADD INDEX (type)";
    if (!$conn->query($addIndexQuery)) {
        // Index might already exist, continue anyway
        error_log("Index creation note: " . $conn->error);
    }
    
    // Change unit_price from INT to DECIMAL if needed
    $alterPriceQuery = "ALTER TABLE inventory MODIFY COLUMN unit_price DECIMAL(10, 2) NOT NULL DEFAULT 0.00";
    if (!$conn->query($alterPriceQuery)) {
        // Might fail if already DECIMAL, that's ok
        error_log("Price column note: " . $conn->error);
    }
    
    respond(["status" => "success", "message" => "Database migration completed successfully"]);
    
} catch (Exception $e) {
    respond(["status" => "error", "message" => $e->getMessage()], 500);
}

