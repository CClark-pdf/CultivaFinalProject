<?php
// Start output buffering to avoid accidental whitespace or warnings breaking JSON
ob_start();
header("Access-Control-Allow-Origin: *");
header('Content-Type: application/json; charset=utf-8');
include "db.php";

function respond($payload, $code = 200){
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    ob_clean();
    http_response_code($code);
    echo json_encode($payload);
    exit;
}

// get_orders endpoint

$query = "
    SELECT o.id, o.code, o.status, o.created_at,
           i.item_name, i.qty, i.price
    FROM orders o
    LEFT JOIN order_items i ON o.id = i.order_id
    ORDER BY o.id DESC
";

 $res = $conn->query($query);

 if (!$res) {
     respond(["status"=>"error","message" => $conn->error], 500);
 }

 $orders = [];

 while ($row = $res->fetch_assoc()) {
    // row fetched
    $id = $row["id"];

    if (!isset($orders[$id])) {
        $orders[$id] = [
            "id" => $id,
            "code" => $row["code"],
            "status" => $row["status"],
            "date" => $row["created_at"],
            "items" => []
        ];
    }

    if ($row["item_name"]) {
        $orders[$id]["items"][] = [
            "name" => $row["item_name"],
            "qty" => $row["qty"],
            "price" => $row["price"]
        ];
    }
}
// Ensure no stray output and return JSON
respond(["status"=>"success","data"=>array_values($orders)]);

