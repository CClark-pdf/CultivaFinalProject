<?php
if (!ob_get_level()) ob_start();
function respond($payload, $code = 200){
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    ob_clean();
    http_response_code($code);
    echo json_encode($payload);
    exit;
}
include "db.php";

$updates = [
    'Arabica Coffee Beans' => 'beverages',
    'Bread' => 'pastries',
    'Breadpan' => 'pastries',
    'Caramel Syrup' => 'condiments',
    'clark' => 'other',
    'Cookies' => 'pastries',
    'Cups (100pcs)' => 'utensils',
    'dad' => 'other',
    'Milk (1L)' => 'beverages',
    'Napkins (500pcs)' => 'utensils',
    'Sugar (1kg)' => 'condiments',
    'Vanilla Syrup' => 'condiments'
];

foreach ($updates as $name => $type) {
    $sql = 'UPDATE inventory SET type = ? WHERE item_name = ?';
    $stmt = $conn->prepare($sql);
    if (!$stmt) continue; // skip if prepare fails
    $stmt->bind_param('ss', $type, $name);
    $stmt->execute();
    $stmt->close();
}

respond(["status" => "success", "message" => "All items categorized."]);

