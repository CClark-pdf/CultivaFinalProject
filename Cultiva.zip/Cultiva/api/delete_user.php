<?php
if (!ob_get_level()) ob_start();
function respond($payload, $code = 200){
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    ob_clean();
    http_response_code($code);
    echo json_encode($payload);
    exit;
}
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST");

include "db.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(["status" => "error", "message" => "Only POST allowed"], 405);
}

$data = json_decode(file_get_contents('php://input'), true);
if (!isset($data['id'])) {
    respond(["status" => "error", "message" => "Missing id"], 400);
}

$id = intval($data['id']);

// Do not allow deleting the last admin: simple protection
// Count admins
$admRes = $conn->query("SELECT COUNT(*) as cnt FROM users WHERE role = 'admin'");
if ($admRes) {
    $row = $admRes->fetch_assoc();
    $adminCount = intval($row['cnt']);
    // check if deleting an admin and it's the only one
    $check = $conn->prepare("SELECT role FROM users WHERE id = ?");
    $check->bind_param('i', $id);
    $check->execute();
    $r = $check->get_result()->fetch_assoc();
    $check->close();
    if ($r && $r['role'] === 'admin' && $adminCount <= 1) {
        respond(["status" => "error", "message" => "Cannot delete the only admin account"], 400);
    }
}

$stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
if (!$stmt) {
    respond(["status" => "error", "message" => "Prepare failed: " . $conn->error], 500);
}
$stmt->bind_param('i', $id);
if (!$stmt->execute()) {
    $stmt->close();
    respond(["status" => "error", "message" => "Execute failed: " . $stmt->error], 500);
}
$stmt->close();

respond(["status" => "success", "message" => "User deleted"]);
