<?php
if (!ob_get_level()) ob_start();
function respond($payload, $code = 200){
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    ob_clean();
    http_response_code($code);
    echo json_encode($payload);
    exit;
}
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST");

include "db.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(["status" => "error", "message" => "Only POST allowed"], 405);
}

$data = json_decode(file_get_contents("php://input"), true);

// Validate input
if (!isset($data['email']) || !isset($data['password']) || !isset($data['name'])) {
    respond(["status" => "error", "message" => "Missing required fields: email, password, name"], 400);
}

$email = trim($data['email']);
$password = trim($data['password']);
$name = trim($data['name']);
$role = isset($data['role']) ? trim($data['role']) : 'customer';
$role = strtolower($role);

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    respond(["status" => "error", "message" => "Invalid email format"], 400);
}

if (strlen($password) < 6) {
    respond(["status" => "error", "message" => "Password must be at least 6 characters"], 400);
}

$checkStmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
if (!$checkStmt) {
    respond(["status" => "error", "message" => "Prepare failed: " . $conn->error], 500);
}

$checkStmt->bind_param("s", $email);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    $checkStmt->close();
    respond(["status" => "error", "message" => "Email already registered"], 409);
}

$checkStmt->close();

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
if (!$stmt) {
    respond(["status" => "error", "message" => "Prepare failed: " . $conn->error], 500);
}

$stmt->bind_param("ssss", $name, $email, $hashedPassword, $role);

if (!$stmt->execute()) {
    respond(["status" => "error", "message" => "Registration failed: " . $stmt->error], 500);
}

$stmt->close();

respond([
    "status" => "success",
    "message" => "Account created successfully",
    "user" => [
        "name" => $name,
        "email" => $email,
        "role" => $role
    ]
]);
?>
