<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header('Content-Type: application/json; charset=utf-8');

include "db.php";

$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : '';
if (!ob_get_level()) ob_start();
function respond($payload, $code = 200){
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    ob_clean();
    http_response_code($code);
    echo json_encode($payload);
    exit;
}

// GET all inventory items
if ($method === 'GET' && !$action) {
    $query = "SELECT * FROM inventory ORDER BY item_name ASC";
    $res = $conn->query($query);
    
    if (!$res) {
        respond(["status"=>"error", "message"=>$conn->error], 500);
    }
    
    $items = [];
    while ($row = $res->fetch_assoc()) {
        $items[] = $row;
    }
    
    respond(["status"=>"success", "data"=>$items]);
}

// ADD new inventory item
if ($method === 'POST' && $action === 'add') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    // Validate required fields (include `type` to prevent accidental defaulting to 'other')
    $missing = [];
    foreach (['item_name','current_stock','reorder_level','unit_price','supplier','type'] as $f) {
        if (!isset($data[$f]) || ($f === 'type' && trim($data[$f]) === '')) {
            $missing[] = $f;
        }
    }
    if (!empty($missing)) {
        respond(["status"=>"error", "message"=>"Missing required fields: " . implode(', ', $missing)], 400);
    }

    // Normalize type (trim + lowercase)
    $type = strtolower(trim($data['type']));
    $unit_price = floatval($data['unit_price']);
    $item_name = $data['item_name'];
    $current_stock = intval($data['current_stock']);
    $reorder_level = intval($data['reorder_level']);
    $supplier = $data['supplier'];
    
    $stmt = $conn->prepare("INSERT INTO inventory (item_name, type, current_stock, reorder_level, unit_price, supplier) VALUES (?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        respond(["status"=>"error", "message"=>"Prepare failed: " . $conn->error], 500);
    }
    
    $stmt->bind_param("ssiids", $item_name, $type, $current_stock, $reorder_level, $unit_price, $supplier);
    
    if (!$stmt->execute()) {
        $stmt->close();
        respond(["status"=>"error", "message"=>"Execute failed: " . $stmt->error], 500);
    }
    
    $id = $conn->insert_id;
    $stmt->close();
    
    respond(["status"=>"success", "message"=>"Item added", "id"=>$id]);
}

// UPDATE inventory item
if ($method === 'POST' && $action === 'update') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    if (!isset($data['id'])) {
        respond(["status"=>"error", "message"=>"Missing item ID"], 400);
    }
    
    $id = intval($data['id']);
    $item_name = $data['item_name'] ?? null;
    // If type is provided, normalize it; if provided but empty string, treat as 'other'
    if (array_key_exists('type', $data)) {
        $rawType = trim((string)$data['type']);
        $type = $rawType === '' ? 'other' : strtolower($rawType);
    } else {
        $type = null;
    }
    $current_stock = $data['current_stock'] ?? null;
    $reorder_level = $data['reorder_level'] ?? null;
    $unit_price = $data['unit_price'] ?? null;
    $supplier = $data['supplier'] ?? null;
    
    $updates = [];
    $params = [];
    $types = "";
    
    if ($item_name !== null) {
        $updates[] = "item_name = ?";
        $params[] = $item_name;
        $types .= "s";
    }
    if ($type !== null) {
        $updates[] = "type = ?";
        $params[] = $type;
        $types .= "s";
    }
    if ($current_stock !== null) {
        $updates[] = "current_stock = ?";
        $params[] = intval($current_stock);
        $types .= "i";
    }
    if ($reorder_level !== null) {
        $updates[] = "reorder_level = ?";
        $params[] = intval($reorder_level);
        $types .= "i";
    }
    if ($unit_price !== null) {
        $updates[] = "unit_price = ?";
        $params[] = floatval($unit_price);
        $types .= "d";
    }
    if ($supplier !== null) {
        $updates[] = "supplier = ?";
        $params[] = $supplier;
        $types .= "s";
    }
    
    if (empty($updates)) {
        respond(["status"=>"error", "message"=>"No fields to update"], 400);
    }
    
    $params[] = $id;
    $types .= "i";
    
    $query = "UPDATE inventory SET " . implode(", ", $updates) . " WHERE id = ?";
    $stmt = $conn->prepare($query);
    
    if (!$stmt) {
        respond(["status"=>"error", "message"=>"Prepare failed: " . $conn->error], 500);
    }
    
    $stmt->bind_param($types, ...$params);
    
    if (!$stmt->execute()) {
        $stmt->close();
        respond(["status"=>"error", "message"=>"Execute failed: " . $stmt->error], 500);
    }
    
    $stmt->close();
    
    respond(["status"=>"success", "message"=>"Item updated"]);
}

// DELETE inventory item
if ($method === 'POST' && $action === 'delete') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    if (!isset($data['id'])) {
        respond(["status"=>"error", "message"=>"Missing item ID"], 400);
    }
    
    $id = intval($data['id']);
    
    $stmt = $conn->prepare("DELETE FROM inventory WHERE id = ?");
    if (!$stmt) {
        respond(["status"=>"error", "message"=>"Prepare failed: " . $conn->error], 500);
    }
    
    $stmt->bind_param("i", $id);
    
    if (!$stmt->execute()) {
        $stmt->close();
        respond(["status"=>"error", "message"=>"Execute failed: " . $stmt->error], 500);
    }
    
    $stmt->close();
    
    respond(["status"=>"success", "message"=>"Item deleted"]);
}

respond(["status"=>"error", "message"=>"Invalid action or method"], 400);

