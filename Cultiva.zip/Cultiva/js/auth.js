// Get elements
const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const toggleToRegister = document.getElementById("toggleToRegister");
const toggleToLogin = document.getElementById("toggleToLogin");
// Compute API base using the first path segment as project root (e.g. /CULTIVA)
const API_BASE = (function(){
    const origin = window.location.origin;
    const pathname = window.location.pathname || '/';
    const segments = pathname.split('/').filter(Boolean);
    let siteRoot = '';
    if (segments.length > 0) {
        const first = segments[0];
        if (!first.includes('.')) siteRoot = '/' + first;
    }
    return origin + siteRoot + '/api';
})();

// If a `currentUser` is cached locally, sync it with the server so
// role changes made by admin are applied automatically without
// requiring manual clearing of localStorage.
(async function syncCurrentUser(){
    try {
        const raw = localStorage.getItem('currentUser');
        if (!raw) return;
        const cu = JSON.parse(raw);
        if (!cu || !cu.email) return;

        const res = await fetch(`${API_BASE}/get_users.php`);
        if (!res.ok) return;
        const j = await res.json();
        if (j.status !== 'success' || !Array.isArray(j.data)) return;

        const server = j.data.find(u => (u.email || '').toLowerCase() === (cu.email || '').toLowerCase());
        if (server) {
            const updated = { id: server.id, name: server.name, email: server.email, role: server.role };
            localStorage.setItem('currentUser', JSON.stringify(updated));
        }
    } catch (err) {
        console.error('Failed to sync currentUser with server:', err);
    }
})();

// -------------------------
// TOGGLE FORMS
// -------------------------
toggleToRegister.addEventListener("click", () => {
    loginForm.style.display = "none";
    registerForm.style.display = "block";
    toggleToRegister.style.display = "none";
    toggleToLogin.style.display = "inline";
    document.getElementById("registerMessage").textContent = "";
});

toggleToLogin.addEventListener("click", () => {
    loginForm.style.display = "block";
    registerForm.style.display = "none";
    toggleToRegister.style.display = "inline";
    toggleToLogin.style.display = "none";
    document.getElementById("loginMessage").textContent = "";
});

// -------------------------
// LOGIN 
// -------------------------
loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value;
    const messageElem = document.getElementById("loginMessage");

    try {
        console.log('Login attempt to:', `${API_BASE}/login.php`);
            const res = await fetch(`${API_BASE}/auth_api.php`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password })
        });

        // Check if response is JSON before parsing
        const contentType = (res.headers.get('content-type') || '').toLowerCase();
        let result;
        
        if (contentType.includes('application/json')) {
            result = await res.json();
        } else {
            // Server returned non-JSON (HTML error page, etc.)
            const text = await res.text();
            console.error('Non-JSON response from login.php:', text.substring(0, 500));
            throw new Error(`Server returned non-JSON (${res.status}): ${text.substring(0, 200)}`);
        }

        console.log('Login response:', result);

        if (result.status === "success") {
            // Save current user
            localStorage.setItem("currentUser", JSON.stringify(result.user));
            messageElem.textContent = "";

            // Redirect by role (case-insensitive)
            const role = (result.user.role || '').toString().toLowerCase().trim();
            if (role === 'admin' || role.includes('admin')) {
                window.location.href = "dashboard/admin.html";
            } else if (role === 'cashier' || role.includes('cash')) {
                window.location.href = "dashboard/cashier.html";
            } else {
                window.location.href = "menu.html";
            }
        } else {
            messageElem.textContent = result.message || "Login failed";
            messageElem.style.color = "#e74c3c";
        }
    } catch (err) {
        console.error("Login error:", err);
        messageElem.textContent = "Network error: " + err.message;
        messageElem.style.color = "#e74c3c";
    }
});

// -------------------------
// REGISTER 
// -------------------------
registerForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const fullName = document.getElementById("fullName").value.trim();
    const email = document.getElementById("regEmail").value.trim();
    const password = document.getElementById("regPassword").value;
    const messageElem = document.getElementById("registerMessage");

    // Validate password strength
    if (password.length < 6) {
        messageElem.textContent = "Password must be at least 6 characters";
        messageElem.style.color = "#e74c3c";
        return;
    }

    try {
        console.log('Register attempt to:', `${API_BASE}/register.php`);
        const res = await fetch(`${API_BASE}/register.php`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name: fullName, email, password, role: "customer" })
        });

        // Check if response is JSON before parsing
        const contentType = (res.headers.get('content-type') || '').toLowerCase();
        let result;
        
        if (contentType.includes('application/json')) {
            result = await res.json();
        } else {
            // Server returned non-JSON (HTML error page, etc.)
            const text = await res.text();
            console.error('Non-JSON response from register.php:', text.substring(0, 500));
            throw new Error(`Server returned non-JSON (${res.status}): ${text.substring(0, 200)}`);
        }

        console.log('Register response:', result);

        if (result.status === "success") {
            messageElem.textContent = "✓ Account created successfully! Redirecting to login...";
            messageElem.style.color = "#27ae60";
            registerForm.reset();

            // Switch to login after 2 seconds
            setTimeout(() => {
                loginForm.style.display = "block";
                registerForm.style.display = "none";
                toggleToRegister.style.display = "inline";
                toggleToLogin.style.display = "none";
                messageElem.textContent = "";
            }, 2000);
        } else {
            messageElem.textContent = result.message || "Registration failed";
            messageElem.style.color = "#e74c3c";
        }
    } catch (err) {
        console.error("Registration error:", err);
        messageElem.textContent = "Network error: " + err.message;
        messageElem.style.color = "#e74c3c";
    }
});
