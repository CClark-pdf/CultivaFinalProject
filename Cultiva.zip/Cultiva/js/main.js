/* ==========================
   GLOBAL VARIABLES
========================== */
const filterBtns = document.querySelectorAll(".filter-btn");
const sections = document.querySelectorAll(".menu-section");
const searchInput = document.getElementById("searchInput");

const cartToggle = document.getElementById("cartToggle");
const cartSidebar = document.getElementById("cartSidebar");
const cartItemsContainer = document.getElementById("cartItems");
const cartTotal = document.getElementById("cartTotal");
const cartOverlay = document.getElementById("cartOverlay");
const checkoutBtn = document.querySelector(".checkout-btn");

// Dynamic API base to support being served from a sub-path (e.g. /CULTIVA on localhost)
// Compute API base relative to the current document so fetch calls target the correct folder
const API_BASE = (function(){
    const origin = window.location.origin;
    const pathname = window.location.pathname || '/';
    const segments = pathname.split('/').filter(Boolean);
    // If first segment looks like a folder name (not a file), use it as project root.
    let siteRoot = '';
    if (segments.length > 0) {
        const first = segments[0];
        if (!first.includes('.') ) {
            siteRoot = '/' + first;
        }
    }
    return origin + siteRoot + '/api';
})();

let cart = JSON.parse(localStorage.getItem("cart")) || [];

/* ==========================
   MENU FILTERING
========================== */
filterBtns.forEach(btn => {
    btn.addEventListener("click", () => {
        filterBtns.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        const category = btn.dataset.category;

        sections.forEach(section => {
            section.style.display = "none";
            section.style.opacity = "0";
        });

        if(category === "all") {
            sections.forEach(section => {
                section.style.display = "block";
                section.style.opacity = "1";
            });
        }

        sections.forEach(section => {
            if(section.dataset.section === category){
                section.style.display = "block";
                section.style.opacity = "1";
            }
        });
    });
});

/* ==========================
   SEARCH SYSTEM
========================== */
if(searchInput){
    searchInput.addEventListener("input", () => {
        const term = searchInput.value.toLowerCase();
        sections.forEach(section => {
            const cards = section.querySelectorAll(".menu-card");
            let hasMatch = false;

            cards.forEach(card => {
                const name = card.querySelector("h3").textContent.toLowerCase();
                if(name.includes(term)){
                    card.style.display = "flex";
                    hasMatch = true;
                } else card.style.display = "none";
            });

            section.style.display = hasMatch ? "block" : "none";
        });
    });
}

/* ==========================
   CART SYSTEM
========================== */
if(cartToggle){
    cartToggle.addEventListener("click", () => {
        if(cartSidebar) cartSidebar.classList.add("active");
        if(cartOverlay) cartOverlay.classList.add("active");
        if(cartToggle) cartToggle.classList.add("hide");
    });
}
if(cartOverlay){
    cartOverlay.addEventListener("click", () => {
        if(cartSidebar) cartSidebar.classList.remove("active");
        if(cartOverlay) cartOverlay.classList.remove("active");
        if(cartToggle) cartToggle.classList.remove("hide");
    });
}

// Add to cart
document.querySelectorAll(".add-btn").forEach(btn => {
    btn.addEventListener("click", e => {
        const card = e.target.closest(".menu-card");
        const name = card.querySelector("h3").textContent;
        const priceText = card.querySelector(".menu-price").textContent;
        const price = parseInt(priceText.replace(/\D/g,""));

        let item = cart.find(i => i.name === name);
        if(item) item.qty++;
        else cart.push({ name, price, qty:1 });

        localStorage.setItem("cart", JSON.stringify(cart));
        updateCart();
    });
});

// Update cart UI
function updateCart(){
    if(!cartItemsContainer || !cartTotal) return;

    cartItemsContainer.innerHTML = "";
    let total = 0;
    let itemCount = 0;

    cart.forEach(item => {
        itemCount += item.qty;
        total += item.price*item.qty;
        const div = document.createElement("div");
        div.classList.add("cart-item");
        div.innerHTML = `
            <h4>${item.name}</h4>
            <div class="quantity-control">
                <button class="qty-btn" onclick="changeQty('${item.name}', -1)">-</button>
                <span class="qty-number">${item.qty}</span>
                <button class="qty-btn" onclick="changeQty('${item.name}', 1)">+</button>
            </div>
            <p class="price">₱${item.price*item.qty}</p>
        `;
        cartItemsContainer.appendChild(div);
    });

    cartTotal.textContent = "₱" + total;

    // Update cart counter badge
    const cartCounter = document.getElementById("cartCounter");
    if(cartCounter) cartCounter.textContent = itemCount;
}

function changeQty(name, amount){
    let item = cart.find(i => i.name === name);
    if(!item) return;
    item.qty += amount;
    if(item.qty <= 0) cart = cart.filter(i => i.name !== name);

    localStorage.setItem("cart", JSON.stringify(cart));
    updateCart();
}

/* ==========================
   BUTTON CLICK EFFECT
========================== */
function addClickEffect(){
    document.querySelectorAll("button, .filter-btn, .add-btn, .checkout-btn, .qty-btn")
        .forEach(btn => {
            btn.addEventListener("click", () => {
                btn.classList.add("btn-click");
                setTimeout(()=>btn.classList.remove("btn-click"),150);
            });
        });
}
addClickEffect();

/* ==========================
   SEND TO CASHIER – UPDATED (MySQL)
========================== */
if(checkoutBtn){
    checkoutBtn.addEventListener("click", () => {
        if(cart.length === 0){
            alert("Your cart is empty!");
            return;
        }

        const orderCode = "CULT-" + Math.floor(1000 + Math.random()*9000);

        // Send order to cashier (saves as 'pending' so cashier can see and process payment)
        const formData = new FormData();
        formData.append("code", orderCode);
        formData.append("items", JSON.stringify(cart));

        console.log("Sending order to cashier:", { code: orderCode, items: cart });
        // Log computed API base and full endpoint for debugging on XAMPP
        console.log('API_BASE =', API_BASE);
        const saveUrl = `${API_BASE}/save_order.php`;
        console.log('Saving order to', saveUrl, { code: orderCode, items: cart });

        fetch(saveUrl, {
            method: "POST",
            body: formData
        })
        .then(async res => {
            const text = await res.text();
            if(!res.ok) {
                console.error('save_order.php returned HTTP', res.status, text);
            }
            try {
                return JSON.parse(text);
            } catch(e) {
                // non-JSON response — log for debugging
                console.error('Non-JSON response from save_order.php:', text);
                // Detect common anti-bot JS challenge pages (they return HTML with JS that sets cookies and redirects)
                try {
                    const challengeRe = /location\.href\s*=\s*["']([^"']+)["']/i;
                    const slowAesRe = /slowAES\.decrypt|aes\.js|toNumbers\(|document\.cookie/i;
                    const m = text.match(challengeRe);
                    if (m || slowAesRe.test(text)) {
                        console.warn('Anti-bot challenge detected in save_order response. Opening challenge page in a new tab to allow the browser to run the script and set cookies.');
                        try { window.open(saveUrl, '_blank'); } catch(_) {}
                        const userMsg = 'Your host returned an anti-bot challenge page which prevents AJAX calls.\n' +
                            'I opened the challenge page in a new tab — please complete it (the tab will redirect automatically).\n' +
                            'After it finishes, return here and press the Checkout button again.';
                        alert(userMsg);
                        return { status: 'error', message: 'Anti-bot challenge detected. Opened challenge page in new tab.' };
                    }
                } catch(err) {
                    console.error('Error while detecting challenge page:', err);
                }

                return { status: 'error', message: text };
            }
        })
        .then(result => {
            console.log('save_order response', result);
            if(result && result.status === "success"){
                // Order sent to cashier successfully - clear cart and show confirmation
                alert(`✓ Order ${orderCode} sent to cashier!\nPlease proceed to the counter for payment.`);
                cart = [];
                localStorage.removeItem("cart");
                updateCart();
                
                // Close cart sidebar
                if(cartSidebar) cartSidebar.classList.remove("active");
                if(cartOverlay) cartOverlay.classList.remove("active");
                if(cartToggle) cartToggle.classList.remove("hide");

            } else {
                const msg = (result && result.message) ? result.message : 'Unknown error';
                console.error('Order save failed:', msg);
                alert("ERROR saving order: " + msg);
            }
        })
        .catch(err => {
            console.error('Network or parse error saving order', err);
            alert('Network error saving order: ' + err.message);
        });
    });
}

/* ==========================
   PAYMENT UI (Before Payment)
========================== */
let currentOrderForPayment = null;

function showPaymentUI(order) {
    currentOrderForPayment = order;
    const modal = document.getElementById("receiptModal");
    // Show a read-only receipt in the modal. Cashier will mark payments in their interface.
    currentOrderForPayment = order;
    const receiptSection = document.getElementById("receiptSection");
    if(!modal || !receiptSection) return;

    // Populate receipt (read-only)
    const orderCodeElem = document.getElementById("receiptOrderCodeFinal");
    if(orderCodeElem) orderCodeElem.textContent = "Order Code: " + order.code;

    const itemsContainer = document.getElementById("receiptItemsFinal");
    if(itemsContainer) {
        itemsContainer.innerHTML = "";
        let total = 0;
        order.items.forEach(item => {
            const div = document.createElement("div");
            const subtotal = item.price * item.qty;
            total += subtotal;
            div.innerHTML = `<span>${item.name} x${item.qty}</span><span>₱${subtotal}</span>`;
            itemsContainer.appendChild(div);
        });

        const totalElem = document.getElementById("receiptTotalFinal");
        if(totalElem) totalElem.textContent = "Total: ₱" + total;

        const amountGivenElem = document.getElementById("receiptAmountGiven");
        if(amountGivenElem) amountGivenElem.textContent = "Pending";

        const changeElem = document.getElementById("receiptChange");
        if(changeElem) changeElem.textContent = "—";
    }

    const timestampElem = document.getElementById("receiptTimestamp");
    if(timestampElem) timestampElem.textContent = "Date: " + new Date().toLocaleString();

    // Show receipt-only modal
    receiptSection.style.display = "block";
    modal.style.display = "flex";

    const closeBtn = document.getElementById("closeReceipt");
    if(closeBtn) closeBtn.onclick = () => modal.style.display = "none";

    window.onclick = e => { if(e.target === modal) modal.style.display = "none"; };
}

/* ==========================
   COMPLETE PAYMENT & SHOW RECEIPT
========================== */
function completePayment(order, amountGiven) {
    const modal = document.getElementById("receiptModal");
    const receiptSection = document.getElementById("receiptSection");

    if(!modal || !receiptSection) return;

    // Populate receipt
    const orderCodeElem = document.getElementById("receiptOrderCodeFinal");
    if(orderCodeElem) orderCodeElem.textContent = "Order Code: " + order.code;

    const itemsContainer = document.getElementById("receiptItemsFinal");
    if(itemsContainer) {
        itemsContainer.innerHTML = "";
        let total = 0;
        order.items.forEach(item => {
            const div = document.createElement("div");
            const subtotal = item.price * item.qty;
            total += subtotal;
            div.innerHTML = `<span>${item.name} x${item.qty}</span><span>₱${subtotal}</span>`;
            itemsContainer.appendChild(div);
        });

        const totalElem = document.getElementById("receiptTotalFinal");
        if(totalElem) totalElem.textContent = "Total: ₱" + total;

        const amountGivenElem = document.getElementById("receiptAmountGiven");
        if(amountGivenElem) amountGivenElem.textContent = "₱" + amountGiven.toFixed(2);

        const changeElem = document.getElementById("receiptChange");
        const change = amountGiven - total;
        if(changeElem) changeElem.textContent = "₱" + change.toFixed(2);
    }

    const timestampElem = document.getElementById("receiptTimestamp");
    if(timestampElem) timestampElem.textContent = "Date: " + new Date().toLocaleString();

    // Clear cart only after payment is confirmed
    cart = [];
    localStorage.setItem("cart", JSON.stringify(cart));

    // UI reset
    if(cartItemsContainer) cartItemsContainer.innerHTML = "";
    if(cartTotal) cartTotal.textContent = "₱0";

    document.querySelectorAll(".menu-card .qty-number").forEach(q => q.textContent = "0");

    if(cartSidebar) cartSidebar.classList.remove("active");
    if(cartOverlay) cartOverlay.classList.remove("active");
    if(cartToggle) cartToggle.classList.remove("hide");
}

updateCart();
