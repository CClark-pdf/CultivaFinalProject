// ...existing code...
/* ---------- auth check (unchanged) ---------- */
const currentUser = JSON.parse(localStorage.getItem('currentUser'));
if (!currentUser || currentUser.role !== 'admin') {
  window.location.href = '../auth.html';
}

/* ---------- PAGE SWITCH ---------- */
const navItems = document.querySelectorAll('.nav-item');
const sections = {
  stats: document.getElementById('statsPage'),
  users: document.getElementById('usersPage'),
  orders: document.getElementById('ordersPage'),
  inventory: document.getElementById('inventoryPage')
};
navItems.forEach(btn=>{
  btn.addEventListener('click', ()=>{
    navItems.forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    const page = btn.dataset.page;
    document.getElementById('pageTitle').textContent = btn.textContent;
    Object.values(sections).forEach(s=>s.style.display='none');
    sections[page].style.display = 'block';
    // when switching, refresh content
    if(page==='users') renderUsers();
    if(page==='orders') renderOrders();
    if(page==='inventory') renderInventory();
    if(page==='stats') refreshAll(); // refresh charts & stats
  });
});

/* ---------- LOGOUT & ADD USER UI (unchanged) ---------- */
document.getElementById('logoutBtn').addEventListener('click', ()=>{
  localStorage.removeItem('currentUser');
  window.location.href = '../auth.html';
});

// Reset all data button
document.getElementById('resetBtn').addEventListener('click', () => {
  // Check if user is admin
  const currentUser = JSON.parse(localStorage.getItem('currentUser'));
  if (!currentUser || currentUser.role !== 'admin') {
    alert('Only admins can reset data!');
    return;
  }
  
  confirmTitle.textContent = 'Reset All Data';
  confirmText.textContent = 'Are you sure? This will delete all orders and reset inventory to 0. This cannot be undone!';
  confirmCallback = async () => {
    try {
      const res = await fetch(`${API_BASE}/reset_all.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_role: currentUser.role })
      });
      const data = await res.json();
      if (data.status === 'success') {
        alert('All data has been reset successfully!');
        location.reload();
      } else {
        alert('Error: ' + (data.message || 'Failed to reset'));
      }
    } catch (err) {
      console.error(err);
      alert('Error resetting data: ' + err.message);
    }
  };
  confirmModal.style.display = 'flex';
});

// Add user modal
const addUserModal = document.getElementById('addUserModal');
const addUserBtn = document.getElementById('addUserBtn');
const addUserForm = document.getElementById('addUserForm');

addUserBtn.addEventListener('click', ()=> {
  addUserModal.style.display = 'flex';
  document.getElementById('newName').focus();
});
document.getElementById('cancelAddUser').addEventListener('click', ()=>{
  addUserModal.style.display = 'none';
  addUserForm.reset();
});

// Confirm modal utilities
const confirmModal = document.getElementById('confirmModal');
const confirmTitle = document.getElementById('confirmTitle');
const confirmText = document.getElementById('confirmText');
let confirmCallback = null;

document.getElementById('confirmCancel').addEventListener('click', ()=>{
  confirmModal.style.display = 'none';
  confirmCallback = null;
});
document.getElementById('confirmOk').addEventListener('click', ()=>{
  if (typeof confirmCallback === 'function') confirmCallback();
  confirmModal.style.display = 'none';
  confirmCallback = null;
});

/* ---------- USER MANAGEMENT (kept in localStorage) ---------- */
function loadUsersFromStorage(){ return JSON.parse(localStorage.getItem('users')) || []; }
function saveUsersToStorage(u){ localStorage.setItem('users', JSON.stringify(u)); }

async function renderUsers(){
  const tbody = document.getElementById('userTable');
  tbody.innerHTML = '';
  const search = document.getElementById('userSearch')?.value?.toLowerCase() || '';

  try {
    const data = await apiFetchJson(`${API_BASE}/get_users.php`);
    if (data.status !== 'success') throw new Error(data.message || 'Failed to load users');

    const users = data.data || [];

    const filtered = users.filter(u => {
      if(!search) return true;
      return (u.name||'').toLowerCase().includes(search) || (u.email||'').toLowerCase().includes(search) || (u.role||'').toLowerCase().includes(search);
    });

    filtered.forEach(u => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${u.name || ''}</td>
        <td>${u.email || ''}</td>
        <td>${u.role || 'customer'}</td>
        <td>
          <button class="role-btn" data-id="${u.id}" data-role="${u.role}">${u.role === 'admin' ? 'Revoke Admin' : 'Make Admin'}</button>
          <button class="delete-btn" data-id="${u.id}">Delete</button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    // role buttons
    document.querySelectorAll('.role-btn').forEach(btn=>{
      btn.addEventListener('click', async (e)=>{
        const id = btn.dataset.id;
        const currentRole = btn.dataset.role;
        const newRole = currentRole === 'admin' ? 'customer' : 'admin';
        confirmTitle.textContent = currentRole === 'admin' ? 'Revoke Admin' : 'Promote to Admin';
        confirmText.textContent = `Change role of user id ${id} to ${newRole}?`;
        confirmCallback = async ()=>{
          try {
            const resp = await fetch(`${API_BASE}/update_user_role.php`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ id: parseInt(id), role: newRole })
            });
            const j = await resp.json();
            if (j.status !== 'success') throw new Error(j.message || 'Failed to update role');
            await renderUsers();
            refreshAll();
          } catch(err){
            console.error(err);
            alert('Failed to update role: ' + (err.message || '')); 
          }
        };
        confirmModal.style.display = 'flex';
      });
    });

    // delete buttons
    document.querySelectorAll('.delete-btn').forEach(btn=>{
      btn.addEventListener('click', (e)=>{
        const id = btn.dataset.id;
        confirmTitle.textContent = 'Delete User';
        confirmText.textContent = `Are you sure you want to delete user id ${id}?`;
        confirmCallback = async ()=>{
          try {
            const resp = await fetch(`${API_BASE}/delete_user.php`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ id: parseInt(id) })
            });
            const j = await resp.json();
            if (j.status !== 'success') throw new Error(j.message || 'Failed to delete user');
            await renderUsers();
            refreshAll();
          } catch(err){
            console.error(err);
            alert('Failed to delete user: ' + (err.message || ''));
          }
        };
        confirmModal.style.display = 'flex';
      });
    });

    document.getElementById('totalUsers').textContent = users.length;

  } catch (err) {
    console.error('renderUsers error', err);
    tbody.innerHTML = '<tr><td colspan="4">Failed to load users.</td></tr>';
  }
}

// Add user submit - use server API to persist users instead of localStorage
addUserForm.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const name = document.getElementById('newName').value.trim();
  const email = document.getElementById('newEmail').value.trim().toLowerCase();
  const password = document.getElementById('newPassword').value;
  const role = document.getElementById('newRole').value;

  if(!name || !email || !password) return alert('Please fill all fields.');

  try {
    const res = await fetch(`${API_BASE}/register.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password, role })
    });

    if(!res.ok) throw new Error('Network error: ' + res.status);
    const j = await res.json();
    if(j.status !== 'success') throw new Error(j.message || 'Failed to create user');

    addUserModal.style.display = 'none';
    addUserForm.reset();
    // refresh users from server
    await renderUsers();
    await refreshAll();
    alert('User created successfully');
  } catch(err) {
    console.error('Add user failed', err);
    alert('Failed to create user: ' + (err.message || 'Unknown error'));
  }
});

document.getElementById('userSearch').addEventListener('input', ()=> renderUsers());

/* ---------- ORDERS: use API instead of localStorage ---------- */
// Compute API base. Use root-level `/api` which works on this host
// If your app is hosted in a subfolder, set `window.SITE_API_BASE` before this script.
const API_BASE = (function(){
  if (window.SITE_API_BASE) return window.SITE_API_BASE.replace(/\/$/, '');
  const origin = window.location.origin;
  return origin + '/api';
})();

// Helper: fetch and parse JSON with helpful debug logging on failure
async function apiFetchJson(url, options = {}){
  try {
    const res = await fetch(url, options);
    const text = await res.text();
    // Try to parse JSON; if parsing fails, log the raw response for debugging
    try {
      const data = JSON.parse(text);
      if (!res.ok) throw new Error(`HTTP ${res.status}: ${JSON.stringify(data)}`);
      return data;
    } catch(parseErr){
      console.error('apiFetchJson: Failed to parse JSON from', url);
      console.error('Raw response text:\n', text);
      throw new Error('Invalid JSON response from ' + url + ': ' + parseErr.message);
    }
  } catch(err){
    console.error('apiFetchJson error for', url, err);
    throw err;
  }
}

// helper: fetch all orders from DB
async function fetchAllOrders(){
  const data = await apiFetchJson(`${API_BASE}/get_orders.php`);
  // get_orders.php historically returned a raw array; handle both array and wrapped response
  if (Array.isArray(data)) return data;
  if (data && data.status === 'success' && Array.isArray(data.data)) return data.data;
  throw new Error('Unexpected orders response format');
}

// renderOrders now async and uses API
async function renderOrders(){
  const filter = document.getElementById('ordersFilter')?.value || 'all';
  const tbody = document.getElementById('orderTable');
  tbody.innerHTML = '';

  let orders = [];
  try {
    orders = await fetchAllOrders();
  } catch(err){
    console.error(err);
    tbody.innerHTML = '<tr><td colspan="6">Failed to load orders from server.</td></tr>';
    return;
  }

  // normalize statuses: your system uses new/pending/preparing/completed/rejected
  // Admin UI filter had "approved" — we'll treat "approved" as "pending" to remain compatible
  function mapFilterToStatus(f){
    if(f === 'approved') return 'pending';
    return f;
  }
  const mappedFilter = mapFilterToStatus(filter);

  let combined = orders.map(o => ({ ...o }));

  if(mappedFilter !== 'all'){
    combined = combined.filter(o => o.status === mappedFilter);
  }

  combined.forEach(order => {
    let total = 0;
    const itemsText = (order.items || []).map(i => {
      const qty = i.qty || i.q || i.quantity || 1;
      const price = parseFloat(i.price || i.unitPrice || i.amount || 0) || 0;
      total += price * qty;
      return `${i.name || i.title || 'Item'} x${qty}`;
    }).join(', ');

    const tr = document.createElement('tr');

    tr.innerHTML = `
      <td>${order.code}</td>
      <td title="${itemsText}">${(order.items||[]).length} item(s)</td>
      <td>₱${total.toFixed(2)}</td>
      <td>${order.date || '—'}</td>
      <td>${order.status}</td>
      <td></td>
    `;

    // actions cell
    const actionsCell = tr.querySelector('td:last-child');

    if(order.status === 'pending' || order.status === 'new'){
      const approveBtn = document.createElement('button');
      approveBtn.textContent = 'Approve';
      approveBtn.className = 'approve-btn';
      approveBtn.addEventListener('click', ()=> handleApproveOrder(order.code));
      actionsCell.appendChild(approveBtn);

      const rejectBtn = document.createElement('button');
      rejectBtn.textContent = 'Reject';
      rejectBtn.className = 'reject-btn';
      rejectBtn.addEventListener('click', ()=> handleRejectOrder(order.code));
      actionsCell.appendChild(rejectBtn);
    } else {
      const viewBtn = document.createElement('button');
      viewBtn.textContent = 'View';
      viewBtn.addEventListener('click', ()=> {
        // optionally open view modal or go to order details
        alert(`Order ${order.code}\nStatus: ${order.status}\nItems: ${itemsText}`);
      });
      actionsCell.appendChild(viewBtn);
    }

    tbody.appendChild(tr);
  });

  // update totalOrders stat (count of all orders)
  document.getElementById('totalOrders').textContent = orders.length;
}

// orders filter change
document.getElementById('ordersFilter').addEventListener('change', renderOrders);

/* ---------- APPROVE / REJECT via API ---------- */
function postUpdateStatus(code, status){
  return fetch(`${API_BASE}/update_order_status.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ code, status })
  });
}

function handleApproveOrder(code){
  confirmTitle.textContent = 'Approve Order';
  confirmText.textContent = `Approve order ${code}?`;
  confirmCallback = async ()=> {
    try {
      const res = await postUpdateStatus(code, 'pending'); // treat approve -> pending
      if(!res.ok) throw new Error('Failed to update order');
      await renderOrders();
      await refreshAll();
    } catch(e){
      console.error(e);
      alert('Failed to update order status.');
    }
  };
  confirmModal.style.display = 'flex';
}

function handleRejectOrder(code){
  confirmTitle.textContent = 'Reject Order';
  confirmText.textContent = `Reject order ${code}?`;
  confirmCallback = async ()=> {
    try {
      const res = await postUpdateStatus(code, 'rejected');
      if(!res.ok) throw new Error('Failed to update order');
      await renderOrders();
      await refreshAll();
    } catch(e){
      console.error(e);
      alert('Failed to reject order.');
    }
  };
  confirmModal.style.display = 'flex';
}

/* ---------- CHARTS & STATS (use DB orders) ---------- */
let salesLineChart = null;
let ordersBarChart = null;
let topItemsChart = null;

function getDateArray(days = 14){
  const res = [];
  for(let i = days-1; i >= 0; i--){
    const d = new Date();
    d.setDate(d.getDate() - i);
    res.push(d.toLocaleDateString());
  }
  return res;
}

// aggregate sales (completed orders -> sales)
async function aggregateSalesByDate(){
  const orders = await fetchAllOrders();
  const days = getDateArray(14);
  const map = {};
  days.forEach(d => map[d] = 0);

  orders.forEach(order => {
    if(order.status !== 'completed') return; // only completed counts as sale
    const dateKey = (order.date) ? new Date(order.date).toLocaleDateString() : new Date().toLocaleDateString();
    const orderTotal = (order.items || []).reduce((s, i) => {
      const qty = i.qty || i.q || i.quantity || 1;
      const price = parseFloat(i.price || i.unitPrice || i.amount || 0) || 0;
      return s + (price * qty);
    }, 0);
    map[dateKey] = (map[dateKey] || 0) + orderTotal;
  });

  return { labels: Object.keys(map), data: Object.values(map) };
}

// aggregate orders by date (all orders)
async function aggregateOrdersByDate(){
  const orders = await fetchAllOrders();
  const days = getDateArray(14);
  const map = {};
  days.forEach(d => map[d] = 0);

  orders.forEach(order => {
    const dateKey = (order.date) ? new Date(order.date).toLocaleDateString() : new Date().toLocaleDateString();
    map[dateKey] = (map[dateKey] || 0) + 1;
  });

  return { labels: Object.keys(map), data: Object.values(map) };
}

// get top ordered items
async function getTopOrderedItems(){
  try {
    const data = await apiFetchJson(`${API_BASE}/get_top_items.php`);
    console.log('Top items response:', data);
    if(data.status !== 'success') throw new Error(data.message || "Failed to get top items");
    console.log('Top items data:', data.data);
    return data.data || [];
  } catch(err){
    console.error('getTopOrderedItems error:', err);
    return [];
  }
}

async function renderCharts(){
  const salesAgg = await aggregateSalesByDate();
  const ordersAgg = await aggregateOrdersByDate();
  const topItems = await getTopOrderedItems();
  
  console.log('renderCharts - topItems:', topItems, 'length:', topItems.length);

  if(salesLineChart) {
    try { salesLineChart.destroy(); } catch(e){ /* ignore */ }
    salesLineChart = null;
  }
  if(ordersBarChart) {
    try { ordersBarChart.destroy(); } catch(e){ /* ignore */ }
    ordersBarChart = null;
  }
  if (topItemsChart) {
    try { topItemsChart.destroy(); } catch(e){ /* ignore */ }
    topItemsChart = null;
  }

  const lineCanvas = document.getElementById('salesLineChart');
  const barCanvas = document.getElementById('ordersBarChart');
  const pieCanvas = document.getElementById('topItemsChart');

  if(lineCanvas && lineCanvas.getContext) {
    const ctxLine = lineCanvas.getContext('2d');
    salesLineChart = new Chart(ctxLine, {
      type: 'line',
      data: {
        labels: salesAgg.labels,
        datasets: [{
          label: 'Sales (₱)',
          data: salesAgg.data,
          fill: true,
          tension: 0.3,
          borderWidth: 2,
          pointRadius: 3,
          backgroundColor: 'rgba(58,44,38,0.06)',
          borderColor: '#3A2C26'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: { x: { ticks: { maxRotation: 0, autoSkip: true } }, y: { beginAtZero: true } },
        plugins: { legend: { display: false } }
      }
    });
  }

  if(barCanvas && barCanvas.getContext) {
    const ctxBar = barCanvas.getContext('2d');
    ordersBarChart = new Chart(ctxBar, {
      type: 'bar',
      data: {
        labels: ordersAgg.labels,
        datasets: [{
          label: 'Orders',
          data: ordersAgg.data,
          borderRadius: 6,
          borderSkipped: false,
          backgroundColor: '#C6A68D'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: { y: { beginAtZero:true } },
        plugins: { legend: { display:false } }
      }
    });
  }

  if(pieCanvas && pieCanvas.getContext && topItems.length > 0) {
    const ctxPie = pieCanvas.getContext('2d');
    const colors = ['#3A2C26', '#C6A68D', '#8B6F47', '#D4A574', '#E8C4A6', '#6B5344', '#4A3728', '#B8956A', '#F5DEB3', '#9A8276'];
    topItemsChart = new Chart(ctxPie, {
      type: 'pie',
      data: {
        labels: topItems.map(t => t.name),
        datasets: [{
          data: topItems.map(t => t.qty),
          backgroundColor: colors.slice(0, topItems.length),
          borderColor: '#fff',
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom' },
          tooltip: { callbacks: { label: function(ctx) { return ctx.label + ': ' + ctx.parsed + ' items'; } } }
        }
      }
    });
  }
}

/* ---------- REFRESH / SUMMARY ---------- */
async function refreshAll(){
  // get orders from DB
  let orders = [];
  try {
    orders = await fetchAllOrders();
  } catch(err){
    console.error('Failed to fetch orders during refresh', err);
    orders = [];
  }

  // total sales = sum of completed orders
  let totalSales = 0;
  orders.forEach(order=>{
    if(order.status !== 'completed') return;
    const orderTotal = (order.items || []).reduce((s, i) => {
      const qty = i.qty || i.q || i.quantity || 1;
      const price = parseFloat(i.price || i.unitPrice || i.amount || 0) || 0;
      return s + (price * qty);
    }, 0);
    totalSales += orderTotal;
  });

  document.getElementById('totalSales').textContent = '₱' + totalSales.toFixed(2);
  document.getElementById('totalOrders').textContent = orders.length;

  await renderCharts();
}

/* ---------- INIT ---------- */
function init(){
  renderUsers();
  renderOrders();
  renderInventory();
  refreshAll();
}

/* ---------- INVENTORY MANAGEMENT ---------- */
const inventoryModal = document.getElementById('inventoryModal');
const inventoryForm = document.getElementById('inventoryForm');
const cancelInventory = document.getElementById('cancelInventory');
const addInventoryBtn = document.getElementById('addInventoryBtn');
const inventorySearch = document.getElementById('inventorySearch');

let currentEditInventoryId = null;

// Fetch all inventory items
async function fetchInventoryItems() {
  try {
    const data = await apiFetchJson(`${API_BASE}/inventory.php`);
    return data.status === 'success' ? data.data : [];
  } catch (err) {
    console.error("Failed to fetch inventory:", err);
    return [];
  }
}

// Render inventory table
async function renderInventory(filterStatus = 'all') {
  const items = await fetchInventoryItems();
  const tbody = document.getElementById('inventoryTable');
  tbody.innerHTML = '';

  const search = (inventorySearch?.value || '').toLowerCase();

  // Apply status filter
  let filtered = items.filter(item => {
    const stock = parseInt(item.current_stock);
    const reorder = parseInt(item.reorder_level);
    const isLowStock = stock <= reorder;

    if (filterStatus === 'low-stock') return isLowStock;
    if (filterStatus === 'in-stock') return stock > 0 && !isLowStock;
    if (filterStatus === 'out-of-stock') return stock === 0;
    return true; // 'all'
  });

  // Apply search filter
  filtered = filtered.filter(item => {
    if (!search) return true;
    return (item.item_name || '').toLowerCase().includes(search);
  });

  // Calculate stats
  let lowStockCount = 0;
  filtered.forEach(item => {
    if (parseInt(item.current_stock) <= parseInt(item.reorder_level)) {
      lowStockCount++;
    }
  });

  document.getElementById('totalItems').textContent = filtered.length;
  document.getElementById('lowStockCount').textContent = lowStockCount;

  // Render items
  filtered.forEach(item => {
    const stock = parseInt(item.current_stock);
    const reorder = parseInt(item.reorder_level);
    const isLowStock = stock <= reorder;
    const statusText = isLowStock ? '⚠ LOW STOCK' : '✓ OK';
    const statusColor = isLowStock ? '#e74c3c' : '#27ae60';

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${item.item_name}</strong></td>
      <td>${stock}</td>
      <td>${reorder}</td>
      <td>₱${item.unit_price}</td>
      <td>${item.supplier}</td>
      <td style="color:${statusColor};font-weight:bold;">${statusText}</td>
      <td>
        <button class="edit-inv-btn" data-id="${item.id}">Edit</button>
        <button class="delete-inv-btn" data-id="${item.id}">Delete</button>
      </td>
    `;
    tbody.appendChild(tr);
  });

  // Attach edit handlers
  document.querySelectorAll('.edit-inv-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const id = parseInt(e.target.dataset.id);
      const item = items.find(i => i.id == id);
      if (item) openEditInventoryModal(item);
    });
  });

  // Attach delete handlers
  document.querySelectorAll('.delete-inv-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const id = parseInt(e.target.dataset.id);
      const item = items.find(i => i.id == id);
      if (item) {
        confirmTitle.textContent = 'Delete Item';
        confirmText.textContent = `Delete "${item.item_name}" from inventory?`;
        confirmCallback = () => deleteInventoryItem(id);
        confirmModal.style.display = 'flex';
      }
    });
  });
}

// Open add inventory modal
addInventoryBtn.addEventListener('click', () => {
  currentEditInventoryId = null;
  document.getElementById('inventoryModalTitle').textContent = 'Add Item';
  inventoryForm.reset();
  // Reset Type dropdown to placeholder (user must select)
  const invTypeEl = document.getElementById('invType');
  if (invTypeEl) {
    invTypeEl.value = '';
  }
  inventoryModal.style.display = 'flex';
  document.getElementById('invItemName').focus();
});

// Inventory filter dropdown
const inventoryFilter = document.getElementById('inventoryFilter');

if (inventoryFilter) {
  inventoryFilter.addEventListener('change', () => {
    const statusFilter = inventoryFilter.value;
    renderInventory(statusFilter);
  });
}

// Open edit inventory modal
function openEditInventoryModal(item) {
  currentEditInventoryId = item.id;
  document.getElementById('inventoryModalTitle').textContent = 'Edit Item';
  document.getElementById('invItemName').value = item.item_name;
  // Normalize type to lowercase to match select options
  const typeValue = item.type ? item.type.toLowerCase() : '';
  const invTypeSelect = document.getElementById('invType');
  invTypeSelect.value = typeValue || '';
  document.getElementById('invCurrentStock').value = item.current_stock;
  document.getElementById('invReorderLevel').value = item.reorder_level;
  document.getElementById('invUnitPrice').value = item.unit_price;
  document.getElementById('invSupplier').value = item.supplier;
  inventoryModal.style.display = 'flex';
}

// Close inventory modal
cancelInventory.addEventListener('click', () => {
  inventoryModal.style.display = 'none';
  currentEditInventoryId = null;
});

// Save inventory item
inventoryForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const typeEl = document.getElementById('invType');
  const typeValue = typeEl ? (typeEl.value || '').trim().toLowerCase() : '';
  
  const itemData = {
    item_name: document.getElementById('invItemName').value.trim(),
    current_stock: parseInt(document.getElementById('invCurrentStock').value),
    reorder_level: parseInt(document.getElementById('invReorderLevel').value),
    unit_price: parseFloat(document.getElementById('invUnitPrice').value) || 0,
    supplier: document.getElementById('invSupplier').value.trim(),
    type: typeValue
  };
  
  console.log('itemData being sent:', itemData);

  if (!itemData.item_name) {
    alert('Item name is required');
    return;
  }

  try {
    let action = 'add';
    if (currentEditInventoryId) {
      action = 'update';
      itemData.id = currentEditInventoryId;
    }

    // Client-side validation: server requires `type` for add action
    if (action === 'add' && (!itemData.type || itemData.type === '')) {
      alert('Please select an item Type before saving.');
      return;
    }

    const res = await fetch(`${API_BASE}/inventory.php?action=${action}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(itemData)
    });

    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`HTTP ${res.status}: ${txt}`);
    }

    // parse JSON if available, otherwise show server text
    let result;
    const ct = (res.headers.get('content-type') || '').toLowerCase();
    if (ct.includes('application/json')) {
      result = await res.json();
    } else {
      const txt = await res.text();
      throw new Error('Server returned non-JSON: ' + txt);
    }

    if (result.status === 'success') {
      inventoryModal.style.display = 'none';
      currentEditInventoryId = null;
      await renderInventory();
    } else {
      alert('Error: ' + (result.message || 'Unknown error'));
    }
  } catch (err) {
    console.error('Failed to save inventory item:', err);
    alert('Failed to save item: ' + (err.message || err));
  }
});

// Delete inventory item
async function deleteInventoryItem(id) {
  try {
    const res = await fetch(`${API_BASE}/inventory.php?action=delete`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });

    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`HTTP ${res.status}: ${txt}`);
    }

    const ct = (res.headers.get('content-type') || '').toLowerCase();
    let result;
    if (ct.includes('application/json')) {
      result = await res.json();
    } else {
      const txt = await res.text();
      throw new Error('Server returned non-JSON: ' + txt);
    }

    if (result.status === 'success') {
      await renderInventory();
    } else {
      alert('Error: ' + (result.message || 'Unknown error'));
    }
  } catch (err) {
    console.error('Failed to delete inventory item:', err);
    alert('Failed to delete item: ' + (err.message || err));
  }
}

// Search inventory
inventorySearch?.addEventListener('input', () => renderInventory());

/* ---------- INIT ---------- */
function init(){
  try {
    renderUsers().catch(err => console.error('renderUsers error:', err));
    renderOrders().catch(err => console.error('renderOrders error:', err));
    renderInventory().catch(err => console.error('renderInventory error:', err));
    refreshAll().catch(err => console.error('refreshAll error:', err));
    
    // Auto-refresh all data every 15 seconds (always, not just on stats page)
    setInterval(() => {
      refreshAll().catch(err => console.error('auto-refresh error:', err));
    }, 15000);
  } catch (err) {
    console.error('Init error:', err);
  }
}

// Ensure DOM is ready before initializing
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

/* ---------- Extra: keep charts updated if storage changes elsewhere (optional) ---------- */
window.addEventListener('storage', (e)=>{
  if(['users'].includes(e.key)) {
    renderUsers().catch(err => console.error('storage event error:', err));
  }
});