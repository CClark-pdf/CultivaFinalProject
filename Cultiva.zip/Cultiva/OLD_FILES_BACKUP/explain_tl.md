Ito ang Tagalog na paliwanag ng mga pangunahing files at bahagi ng proyekto na "CULTIVA" — isang web-based POS at order management system para sa coffee shop.

Layunin: Ihanda ang maikling, madaling maintindihang presentasyon para ipaliwanag sa mga guro. Kasama rito ang paliwanag ng bawat folder/file group at anong sasabihin kapag ipinapakita.

--

1) `api/db.php` — koneksyon sa database
- Ano ang ginagawa: Dito nakalagay ang mga detalye para kumonekta sa MySQL database (host, username, password, database name). May mga linya na nagbabasa ng environment variables kung available, at kung wala, may default na ginagamit.
- Bakit mahalaga: Kung walang tama at gumaganang koneksyon dito, hindi gagana ang lahat ng API (hindi makaka-save o makaka-load ng orders, users, atbp.).
- Anong sasabihin sa guro: "Dito namin nilalagay ang impormasyon ng database at sinisigurado namin na gumagamit ito ng UTF-8 para tamang pag-handle ng text. Nagbabalik din ito ng malinaw na JSON error kapag hindi nakakonekta." 

2) `api/*.php` — mga API endpoint
- Ano ang ginagawa: Bawat file dito ay isang maliit na API route (hal. `get_orders.php`, `save_order.php`, `record_payment.php`). Karamihan ng mga linya ay nagbabasa ng input, nagpapatakbo ng SQL query, at nagbabalik ng JSON result.
- Bakit mahalaga: Ginagamit sila ng JavaScript sa front-end para kumuha at mag-save ng data nang real-time.
- Anong sasabihin sa guro: "Ang mga ito ang backend endpoints; tumatanggap sila ng request, kumokonekta sa DB, at nagbabalik ng JSON para magamit sa UI. May simpleng error handling para hindi ma-expose ang mga sensitive na detalye."

3) `js/dashboard.cashier.js` — cashier dashboard (client-side)
- Ano ang ginagawa: Ito ang pinakamalaking JavaScript file; nagre-render ng listahan ng orders, nagse-set up ng polling (automatic refresh), nagha-handle ng pag-acknowledge ng order, pag-record ng payment, pag-edit ng items, at pag-view ng receipt.
- Mga uri ng linyang makikita: deklarasyon ng constant (`const`), pagkuha ng DOM elements (`document.getElementById(...)`), `fetch(...)` para tawagan ang `api/*` endpoints, at dynamic na paglikha ng HTML elements at event listeners.
- Anong sasabihin sa guro: "Dito nakasulat ang logic kung paano dinadala ng cashier ang isang order mula 'new' → 'pending' → 'preparing' → 'completed'. Gumagamit ito ng `fetch` para tumawag sa PHP API at nag-a-update ng UI nang hindi nirerefresh ang page."

4) `js/main.js`, `js/auth.js`, `js/dashboard.js` — helper at auth
- Ano ang ginagawa: `main.js` may mga utility (format price, compute API base), `auth.js` humahandle ng login/registration at session storage, at `dashboard.js` para sa admin dashboard features.
- Anong sasabihin sa guro: "Ang `auth.js` ang nag-aasikaso ng login at pag-save ng session, habang ang `main.js` ay naglalaman ng mga gumagawang helper function para mag-work nang maayos ang buong site." 

5) `menu.html`, `index.html` — customer-facing pages
- Ano ang ginagawa: HTML templates para makita ng customer ang menu, mag-add sa cart, at mag-submit ng order.
- Mga linyang makikita: HTML structure (`<section>`, `<div>`, `<button>`), id attributes (`id="cartCounter"`) at script include sa dulo (`<script src="js/main.js"></script>`).
- Anong sasabihin sa guro: "Ito ang UI na ginagamit ng customer; simple at mobile-friendly. Ang interactive behavior ay nilalagay sa JS, kaya puro markup lang dito."

6) `dashboard/cashier.html`, `dashboard/admin.html` — mga dashboard pages
- Ano ang ginagawa: Template ng dashboard layout at modal containers para sa pag-edit at pagtingin ng receipt.
- Anong sasabihin sa guro: "Ito ang mga page na ginagamit ng staff; naka-separate para sa cashier at admin roles. May mga modals para sa pag-edit at pagtingin ng detalye ng order."

7) `db/inventory_table.sql` — schema ng database
- Ano ang ginagawa: SQL file na naglalaman ng `CREATE TABLE` statements at maaaring may `INSERT` sample data.
- Anong sasabihin sa guro: "Dito naka-declare ang estructura ng database — tables para sa `users`, `orders`, `order_items`, at `inventory`. Pinapakita nito kung ano ang mga columns at keys."

8) `css/style.css`, `css/dashboard.css` — style rules
- Ano ang ginagawa: Naglalaman ng CSS rules para sa layout, colors, spacing, at responsive behavior.
- Anong sasabihin sa guro: "Nagbibigay ito ng visual style ng app; may mga class na ginagamit para sa sidebar, modals, buttons, at grid ng menu items." 

9) `cultiva-cashier-fix/` — alternate cashier page (backup)
- Ano ang ginagawa: Legacy or alternate version ng cashier interface; maaaring ginagamit para mabilisang pag-troubleshoot o backward compatibility.

Paano i-presenta sa guro — mabilis na script
- Intro (10–15s): "Ang CULTIVA ay isang web-based POS system para sa coffee shop na gawa namin gamit HTML/CSS/JS sa frontend at PHP/MySQL sa backend."
- Demo flow (1–2 min): "Una, customer nag-order sa `menu.html`. Ang order ay nai-send sa API (`save_order.php`). Sa cashier dashboard (`dashboard/cashier.html`) makikita agad ang bagong order; maaaring i-acknowledge, i-record ang payment, at i-complete."
- Technical explanation (2–3 min): "Ang backend ay nasa `api/` folder; lahat ng endpoints ay nagbabalik ng JSON. Ang `api/db.php` ay may koneksyon sa DB at gumagamit ng environment variables kapag available. Ang `js/dashboard.cashier.js` ang siyang nagre-render ng mga order cards at nagha-handle ng interaction."
- Q&A (optional): Ihanda ang `ping_db.php` at `get_orders.php` bilang mabilis na proof na tumatakbo ang API.

--

Kung gusto ninyo, gagawing mas detalyado ko pa ang Tagalog na paliwanag per-file (per-line comments) para gawing handout o slide notes. Sabihin lang kung alin ang gusto niyong i-annotate nang buo (hal. `js/dashboard.cashier.js`).

*** End ng explain_tl.md