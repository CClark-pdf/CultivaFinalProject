# CULTIVA Testing Guide

## ✅ What Should Work

### 1. Cashier Dashboard (dashboard/cashier.html)
**Location:** http://localhost/CULTIVA/dashboard/cashier.html

**Expected:**
- Dashboard shows 4 tabs: New Orders, Pending, Preparing, Completed
- New Orders tab displays all orders with status = "new"
- For each order:
  - Order code (e.g., CULT-2559)
  - Items list (Americano x1, etc.)
  - Total price (₱100)
  - Three buttons: ✓ Acknowledge, ✗ Reject, Edit

**If Not Working:**
1. Open Browser DevTools (F12)
2. Go to Console tab - look for red errors
3. Go to Network tab - check if `get_orders.php` returns data
4. Check if auth is working - you should see current user

### 2. Admin Dashboard (dashboard/admin.html)

**Statistics Tab:**
- Shows 3 stat cards: Total Sales, Total Orders, Registered Users
- Displays 2 charts:
  - Sales (Line chart) - last 14 days, only completed orders
  - Orders (Bar chart) - all orders

**If Charts Don't Show:**
1. F12 → Console - check for errors
2. Look for network request to `get_orders.php`
3. Verify Chart.js library loaded (search for "Chart" in console)

## 🔧 Troubleshooting Steps

### Cashier Orders Not Loading
```
1. Check Network tab - POST to update_order_status.php
2. Check Console for fetch errors
3. Verify data structure: should return array of orders
4. Try manually hitting: http://localhost/CULTIVA/api/get_orders.php
```

### Admin Charts Not Rendering
```
1. Check if Chart.js is loaded (<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>)
2. Verify salesLineChart and ordersBarChart canvas elements exist
3. Check Console for "Chart is not defined"
4. Verify fetchAllOrders() is being called and returns data
```

### Common Errors & Fixes
- **"fetchAllOrders is not defined"** → dashboard.js not loaded
- **No orders showing** → get_orders.php not returning data
- **"Chart is not defined"** → Chart.js CDN not loaded
- **403 Forbidden** → Files not copied to XAMPP htdocs

## ✅ Quick Verification
```powershell
# Test API endpoints
Invoke-RestMethod -Uri 'http://localhost/CULTIVA/api/get_orders.php' -Method Get

# Check files in XAMPP
Test-Path 'C:\xampp\htdocs\CULTIVA\dashboard\cashier.html'
Test-Path 'C:\xampp\htdocs\CULTIVA\js\dashboard.cashier.js'
Test-Path 'C:\xampp\htdocs\CULTIVA\js\dashboard.js'
```
