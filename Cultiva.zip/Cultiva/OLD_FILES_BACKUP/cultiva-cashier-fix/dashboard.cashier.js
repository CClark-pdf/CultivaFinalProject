/* dashboard.cashier.js
   Cashier Dashboard: manage orders (new -> pending -> preparing -> completed)
   Features: acknowledge, reject, edit items, delete items, complete order
*/

// Compute API base: use SITE_API_BASE if set, otherwise default to root /api
const API_BASE = (function(){
  if (window.SITE_API_BASE) return window.SITE_API_BASE.replace(/\/$/, '');
  const origin = window.location.origin;
  return origin + '/api';
})();

/* ---------- MENU ITEMS DATABASE ---------- */
const MENU_ITEMS = [
  // Espresso
  { name: "Americano", price: 100, category: "espresso" },
  { name: "Cafe Latte", price: 115, category: "espresso" },
  { name: "Cappuccino", price: 115, category: "espresso" },
  { name: "Salted Caramel Latte", price: 135, category: "espresso" },
  { name: "Dark Mocha Latte", price: 135, category: "espresso" },
  { name: "White Mocha", price: 135, category: "espresso" },
  { name: "Vanilla Latte", price: 135, category: "espresso" },
  { name: "Hazelnut Latte", price: 135, category: "espresso" },
  { name: "Spanish Latte", price: 135, category: "espresso" },
  { name: "Caramel Macchiato", price: 155, category: "espresso" },
  { name: "Sea Salt Latte", price: 155, category: "espresso" },
  // Cultiva Shots
  { name: "Double Espresso", price: 155, category: "cultiva-shots" },
  { name: "Iced Dulce", price: 165, category: "cultiva-shots" },
  { name: "Hazelnut Shaken Espresso", price: 165, category: "cultiva-shots" },
  { name: "Peanut Butter Latte", price: 165, category: "cultiva-shots" },
  { name: "Cookie Butter Latte (Biscoff)", price: 175, category: "cultiva-shots" },
  // Frappe
  { name: "Java Chip Frappe", price: 165, category: "frappe" },
  { name: "Cookies & Cream Frappe", price: 165, category: "frappe" },
  { name: "Dark Mocha Frappe", price: 165, category: "frappe" },
  { name: "White Mocha Frappe", price: 165, category: "frappe" },
  { name: "Salted Caramel Frappe", price: 165, category: "frappe" },
  { name: "Cookie Butter Frappe (Biscoff)", price: 175, category: "frappe" },
  // Milkshake
  { name: "Oreo Matcha Milkshake", price: 165, category: "milkshake" },
  { name: "Matcha Milkshake", price: 165, category: "milkshake" },
  { name: "Strawberry & Cream Milkshake", price: 165, category: "milkshake" },
  { name: "Chocolate Milkshake", price: 165, category: "milkshake" },
  { name: "Cookies & Cream Milkshake", price: 165, category: "milkshake" },
  { name: "Cookie Butter Milkshake (Biscoff)", price: 175, category: "milkshake" },
  { name: "Oreo Lotus Milkshake", price: 175, category: "milkshake" },
  // Tea
  { name: "Detox Tea", price: 155, category: "tea" },
  { name: "Hibiscus Tea", price: 155, category: "tea" },
  { name: "Passion Green Tea", price: 155, category: "tea" },
  // Non-Coffee
  { name: "Matcha", price: 150, category: "noncoffee" },
  { name: "Sea Salt Matcha", price: 175, category: "noncoffee" },
  { name: "Chocolate", price: 135, category: "noncoffee" },
  // Add-ons
  { name: "Espresso Shot", price: 50, category: "addons" },
  { name: "Sea Salt Cream Cheese", price: 40, category: "addons" },
  { name: "Whipped Cream", price: 25, category: "addons" },
  { name: "Sauce/Syrup (per pump)", price: 35, category: "addons" },
  { name: "Biscoff Lotus (per spoon)", price: 50, category: "addons" }
];

/* ---------- AUTH CHECK ---------- */
const currentUser = JSON.parse(localStorage.getItem("currentUser"));
if (!currentUser || currentUser.role !== "cashier") {
  window.location.href = "../auth.html";
}

/* ---------- DOM SELECTORS ---------- */
const navItems = document.querySelectorAll(".nav-item");
const pageTitle = document.getElementById("pageTitle");
const refreshBtn = document.getElementById("refreshBtn");
const logoutBtn = document.getElementById("logoutBtn");

const lists = {
  pending: document.getElementById("pendingList"),
  preparing: document.getElementById("preparingList"),
  completed: document.getElementById("completedList")
};

const pages = {
  pending: document.getElementById("pendingPage"),
  preparing: document.getElementById("preparingPage"),
  completed: document.getElementById("completedPage")
};

const editModal = document.getElementById("editModal");
const editCancel = document.getElementById("editCancel");
const editSave = document.getElementById("editSave");
const editItems = document.getElementById("editItems");
const addItemBtn = document.getElementById("addItemBtn");

let currentEditCode = "";
let currentEditItems = []; // Track items being edited in the modal

// Polling control so we can pause while cashier is interacting
let cashierPollIntervalId = null;
function startCashierPolling() {
  if (cashierPollIntervalId) clearInterval(cashierPollIntervalId);
  cashierPollIntervalId = setInterval(renderAll, 5000);
}
function stopCashierPolling() {
  if (cashierPollIntervalId) {
    clearInterval(cashierPollIntervalId);
    cashierPollIntervalId = null;
  }
}

/* ---------- FETCH ORDERS FROM DB ---------- */
async function getOrdersFromDB() {
  try {
    console.log('Cashier: fetching orders from', `${API_BASE}/get_orders.php`);
    const res = await fetch(`${API_BASE}/get_orders.php`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.error("Failed to fetch orders:", err);
    return [];
  }
}

/* ---------- NAVIGATION ---------- */
navItems.forEach(btn => {
  btn.addEventListener("click", () => {
    navItems.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    const page = btn.dataset.page;
    if (pageTitle) pageTitle.textContent = btn.textContent;
    Object.keys(pages).forEach(k => {
      if (pages[k]) pages[k].style.display = (k === page) ? "block" : "none";
    });
    renderAll();
  });
});

/* ---------- REFRESH BUTTON ---------- */
if (refreshBtn) refreshBtn.addEventListener("click", renderAll);

/* ---------- LOGOUT ---------- */
if (logoutBtn) {
  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("currentUser");
    window.location.href = "../auth.html";
  });
}

/* ---------- RENDER ORDER CARDS ---------- */
async function renderAll() {
  const orders = await getOrdersFromDB();
  
  Object.keys(lists).forEach(status => {
    if (lists[status]) lists[status].innerHTML = "";
  });

  orders.forEach(order => {
    const card = createOrderCard(order);
    const status = order.status || "new";
    if (lists[status]) {
      lists[status].appendChild(card);
    }
  });
}

function createOrderCard(order) {
  const card = document.createElement("div");
  card.className = "stat-card order-card";
  
  const total = (order.items || []).reduce((sum, item) => {
    const qty = parseInt(item.qty) || 1;
    const price = parseInt(item.price) || 0;
    return sum + (price * qty);
  }, 0);

  const itemsText = (order.items || [])
    .map(i => `${i.name} x${i.qty}`)
    .join(", ");

  card.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;">
      <div style="font-weight:700;font-size:16px;">${order.code}</div>
      <div style="font-size:12px;color:#999;">${order.date || '—'}</div>
    </div>
    <div style="margin-top:10px;color:#666;font-size:13px;">${itemsText}</div>
    <div style="margin-top:10px;font-weight:700;font-size:15px;">₱${total.toFixed(2)}</div>
    <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;"></div>
  `;

  const actionsDiv = card.querySelector("div:last-child");

  // Status-specific action buttons
  const status = order.status || "new";

  if (status === "new") {
    // New order: acknowledge or reject
    const ackBtn = document.createElement("button");
    ackBtn.type = 'button';
    ackBtn.textContent = "✓ Acknowledge";
    ackBtn.className = "approve-btn action-btn";
    ackBtn.addEventListener("click", () => handleStatusChange(order.code, "pending"));
    actionsDiv.appendChild(ackBtn);

    const rejectBtn = document.createElement("button");
    rejectBtn.type = 'button';
    rejectBtn.textContent = "✗ Reject";
    rejectBtn.className = "reject-btn action-btn";
    rejectBtn.addEventListener("click", () => handleStatusChange(order.code, "rejected"));
    actionsDiv.appendChild(rejectBtn);

    const editBtn = document.createElement("button");
    editBtn.type = 'button';
    editBtn.textContent = "Edit";
    editBtn.className = "primary-btn action-btn";
    editBtn.addEventListener("click", () => openEditModal(order.code));
    actionsDiv.appendChild(editBtn);
  } else if (status === "pending") {
    // Pending: show payment input + mark paid, and also start preparing
    const amountInput = document.createElement('input');
    amountInput.type = 'number';
    amountInput.min = '0';
    amountInput.step = '0.01';
    amountInput.placeholder = 'Amount Paid (₱)';
    amountInput.style.padding = '8px';
    amountInput.style.width = '140px';
    amountInput.style.borderRadius = '6px';
    amountInput.style.border = '1px solid #ddd';
    actionsDiv.appendChild(amountInput);

    const changeSpan = document.createElement('div');
    changeSpan.style.marginTop = '6px';
    changeSpan.style.fontSize = '13px';
    changeSpan.style.color = '#333';
    changeSpan.textContent = '';
    actionsDiv.appendChild(changeSpan);

    const markPaidBtn = document.createElement("button");
    markPaidBtn.type = 'button';
    markPaidBtn.textContent = "Mark Paid";
    markPaidBtn.className = "approve-btn action-btn";
    markPaidBtn.addEventListener('click', async () => {
      const amount = parseFloat(amountInput.value) || 0;
      // Calculate total from items shown on card
      const total = (order.items || []).reduce((s,it)=> s + (parseFloat(it.price||0) * parseInt(it.qty||1)), 0);
      if (amount < total) {
        alert(`Insufficient payment: short by ₱${(total - amount).toFixed(2)}`);
        return;
      }
      // Call record_payment API
      try {
        const res = await fetch(`${API_BASE}/record_payment.php`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ code: order.code, amount })
        });
        const json = await res.json();
        if (json && json.status === 'success') {
          alert(`Payment recorded. Change: ₱${json.change}`);
          // Save amount to localStorage before moving to preparing
          const key = `pendingPayment:${order.code}`;
          try { localStorage.setItem(key, amount.toString()); } catch(e) {}
          // Move order to preparing status
          await handleStatusChange(order.code, "preparing");
        } else {
          alert('Payment failed: ' + (json.message || 'Unknown'));
        }
      } catch (err) {
        console.error('Payment error', err);
        alert('Network error recording payment');
      }
    });
    actionsDiv.appendChild(markPaidBtn);

    const editBtn = document.createElement("button");
    editBtn.type = 'button';
    editBtn.textContent = "Edit";
    editBtn.className = "primary-btn action-btn";
    editBtn.addEventListener("click", () => openEditModal(order.code));
    actionsDiv.appendChild(editBtn);

    // live change calculation
    amountInput.addEventListener('input', () => {
      const amt = parseFloat(amountInput.value) || 0;
      const total = (order.items || []).reduce((s,it)=> s + (parseFloat(it.price||0) * parseInt(it.qty||1)), 0);
      const ch = amt - total;
      if (!amountInput.value) changeSpan.textContent = '';
      else if (ch < 0) changeSpan.textContent = `Short by ₱${Math.abs(ch).toFixed(2)}`;
      else changeSpan.textContent = `Change: ₱${ch.toFixed(2)}`;
      // Persist entered amount so it can be shown if status changes to preparing
      const key = `pendingPayment:${order.code}`;
      if (amountInput.value) {
        try { localStorage.setItem(key, amountInput.value); } catch (e) { /* ignore */ }
      } else {
        try { localStorage.removeItem(key); } catch (e) { /* ignore */ }
      }
    });
    // Pause polling while cashier is typing an amount to avoid accidental reset
    amountInput.addEventListener('focus', () => stopCashierPolling());
    amountInput.addEventListener('blur', () => startCashierPolling());
  } else if (status === "preparing") {
    // Preparing: show any entered amount and complete
    const storedKey = `pendingPayment:${order.code}`;
    const storedVal = (function(){ try { return localStorage.getItem(storedKey); } catch(e) { return null; } })();
    if (storedVal) {
      const paidAmt = parseFloat(storedVal) || 0;
      const ch = paidAmt - total;
      const paymentInfo = document.createElement('div');
      paymentInfo.style.marginTop = '8px';
      paymentInfo.style.fontSize = '13px';
      paymentInfo.style.color = '#333';
      if (ch < 0) paymentInfo.textContent = `Amount Entered: ₱${paidAmt.toFixed(2)} — Short by ₱${Math.abs(ch).toFixed(2)}`;
      else paymentInfo.textContent = `Amount Entered: ₱${paidAmt.toFixed(2)} — Change: ₱${ch.toFixed(2)}`;
      actionsDiv.insertAdjacentElement('beforebegin', paymentInfo);
    }
    // Preparing: complete
    const completeBtn = document.createElement("button");
    completeBtn.type = 'button';
    completeBtn.textContent = "✓ Complete";
    completeBtn.className = "approve-btn action-btn";
    completeBtn.addEventListener("click", () => handleStatusChange(order.code, "completed"));
    actionsDiv.appendChild(completeBtn);
  } else if (status === "completed") {
    // Completed: view only (could add archive/delete later)
    const viewBtn = document.createElement("button");
    viewBtn.type = 'button';
    viewBtn.textContent = "View";
    viewBtn.className = "primary-btn action-btn";
    viewBtn.disabled = true;
    actionsDiv.appendChild(viewBtn);
  } else if (status === "rejected") {
    // Rejected: view
    const viewBtn = document.createElement("button");
    viewBtn.type = 'button';
    viewBtn.textContent = "View";
    viewBtn.className = "reject-btn action-btn";
    viewBtn.disabled = true;
    actionsDiv.appendChild(viewBtn);
  }

  return card;
}

/* ---------- STATUS CHANGE (via API) ---------- */
async function handleStatusChange(code, newStatus) {
  try {
    const res = await fetch(`${API_BASE}/update_order_status.php`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code, status: newStatus })
    });
    // Check response content-type before parsing
    const contentType = (res.headers.get('content-type') || '').toLowerCase();

    let result = null;
    if (contentType.includes('application/json')) {
      try {
        result = await res.json();
      } catch (parseErr) {
        const text = await res.text();
        throw new Error(`Invalid JSON response: ${text}`);
      }
    } else {
      // Non-JSON response (plain text or HTML) - read as text for debugging
      const text = await res.text();
      throw new Error(`Non-JSON response from server: ${text}`);
    }

    if (!res.ok) {
      const msg = (result && result.message) ? result.message : `HTTP ${res.status}`;
      throw new Error(msg);
    }

    console.log(`Order ${code} status changed to ${newStatus}`, result);
    renderAll();
  } catch (err) {
    console.error("Failed to update status:", err);
    // Show clearer, actionable error to the cashier
    alert(`Failed to update order status: ${err.message}`);
  }
}

/* ---------- EDIT MODAL ---------- */
function openEditModal(code) {
  currentEditCode = code;
  if (editItems) editItems.innerHTML = "";

  fetch(`${API_BASE}/get_orders.php`)
    .then(res => res.json())
    .then(allOrders => {
      const order = allOrders.find(o => o.code === code);
      if (!order) {
        alert("Order not found");
        return;
      }

      // Use a working copy for edits (not the original order object)
      // Only load from DB if currentEditItems is empty (first open)
      if (currentEditItems.length === 0) {
        currentEditItems = JSON.parse(JSON.stringify(order.items || []));
      }

      renderEditModalItems();

      editModal.style.display = "flex";
      if (editModal) editModal.style.display = "flex";
    })
    .catch(err => {
      console.error("Failed to open edit modal:", err);
      alert("Failed to load order for editing");
    });
}

// Helper function to render items in the modal (used for both initial load and re-render after remove)
function renderEditModalItems() {
  if (editItems) editItems.innerHTML = "";
  
  // Render each item with edit fields + remove button
  currentEditItems.forEach((item, idx) => {
    const itemDiv = document.createElement("div");
    itemDiv.style.marginBottom = "12px";
    itemDiv.style.padding = "10px";
    itemDiv.style.border = "1px solid #ddd";
    itemDiv.style.borderRadius = "4px";
    
    const nameInp = document.createElement("input");
    nameInp.type = "text";
    nameInp.placeholder = "Item name";
    nameInp.value = item.name;
    nameInp.className = "edit-name";
    nameInp.style.cssText = "flex:1;padding:6px;border:1px solid #ccc;border-radius:4px;";
    nameInp.addEventListener("change", (function(i) {
      return function(e) {
        currentEditItems[i].name = e.target.value;
        console.log("Updated name for item", i, "to", e.target.value);
      };
    })(idx));
    
    const qtyInp = document.createElement("input");
    qtyInp.type = "number";
    qtyInp.placeholder = "Qty";
    qtyInp.value = item.qty || 1;
    qtyInp.min = "1";
    qtyInp.className = "edit-qty";
    qtyInp.style.cssText = "width:60px;padding:6px;border:1px solid #ccc;border-radius:4px;";
    qtyInp.addEventListener("change", (function(i) {
      return function(e) {
        currentEditItems[i].qty = parseInt(e.target.value) || 1;
        console.log("Updated qty for item", i, "to", currentEditItems[i].qty);
      };
    })(idx));
    
    const priceInp = document.createElement("input");
    priceInp.type = "number";
    priceInp.placeholder = "Price";
    priceInp.value = item.price || 0;
    priceInp.min = "0";
    priceInp.className = "edit-price";
    priceInp.style.cssText = "width:70px;padding:6px;border:1px solid #ccc;border-radius:4px;";
    priceInp.addEventListener("change", (function(i) {
      return function(e) {
        currentEditItems[i].price = parseInt(e.target.value) || 0;
        console.log("Updated price for item", i, "to", currentEditItems[i].price);
      };
    })(idx));
    
    const removeBtn = document.createElement("button");
    removeBtn.type = "button";
    removeBtn.textContent = "Remove";
    removeBtn.className = "reject-btn";
    removeBtn.style.cssText = "padding:6px 10px;";
    // Create a closure to properly capture the index
    removeBtn.addEventListener("click", (function(removeIdx) {
      return function(e) {
        e.preventDefault();
        console.log("Removing item at index:", removeIdx, "currentEditItems before:", currentEditItems.length);
        currentEditItems.splice(removeIdx, 1);
        console.log("currentEditItems after:", currentEditItems.length);
        renderEditModalItems(); // Re-render just the items, don't re-fetch from DB
      };
    })(idx));
    
    const wrapper = document.createElement("div");
    wrapper.style.cssText = "display:flex;gap:10px;align-items:center;";
    wrapper.appendChild(nameInp);
    wrapper.appendChild(qtyInp);
    wrapper.appendChild(priceInp);
    wrapper.appendChild(removeBtn);
    
    itemDiv.appendChild(wrapper);
    if (editItems) editItems.appendChild(itemDiv);
  });
}

/* ---------- EDIT MODAL BUTTONS ---------- */
editCancel.addEventListener("click", () => {
  editModal.style.display = "none";
  currentEditCode = "";
});

editSave.addEventListener("click", async () => {
  console.log("Save clicked. currentEditItems:", currentEditItems);
  
  // Use currentEditItems directly (which reflects removals)
  const finalItems = currentEditItems.map(item => ({
    name: item.name || "Item",
    qty: parseInt(item.qty) || 1,
    price: parseInt(item.price) || 0
  }));

  console.log("Sending items to API:", finalItems);
  
  try {
    const res = await fetch(`${API_BASE}/edit_order_items.php`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code: currentEditCode, items: finalItems })
    });
    const text = await res.text();
    console.log("API response:", text);
    
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${text}`);
    console.log("Order items updated");
    editModal.style.display = "none";
    currentEditCode = "";
    currentEditItems = [];
    renderAll();
  } catch (err) {
    console.error("Failed to save order items:", err);
    alert(`Failed to save order: ${err.message}`);
  }
});

addItemBtn.addEventListener("click", () => {
  // Add a new item to currentEditItems first
  const newItem = { name: "", qty: 1, price: 0 };
  currentEditItems.push(newItem);
  
  const newItemDiv = document.createElement("div");
  newItemDiv.style.marginBottom = "12px";
  newItemDiv.style.padding = "10px";
  newItemDiv.style.border = "1px solid #ddd";
  newItemDiv.style.borderRadius = "4px";
  
  // Create dropdown with all menu items
  let drinkOptions = '<option value="">-- Select a drink --</option>';
  MENU_ITEMS.forEach(item => {
    drinkOptions += `<option value="${item.name}|${item.price}">${item.name} (₱${item.price})</option>`;
  });
  
  newItemDiv.innerHTML = `
    <div style="display:flex;gap:10px;align-items:center;">
      <select class="edit-drink-select" style="flex:1;padding:6px;border:1px solid #ccc;border-radius:4px;">
        ${drinkOptions}
      </select>
      <input type="number" placeholder="Qty" value="1" min="1" class="edit-qty" style="width:60px;padding:6px;border:1px solid #ccc;border-radius:4px;" />
      <input type="number" placeholder="Price" value="0" min="0" class="edit-price" style="width:70px;padding:6px;border:1px solid #ccc;border-radius:4px;" />
    </div>
  `;
  editItems.appendChild(newItemDiv);
  
  // Add change event to auto-fill price and sync to currentEditItems
  const selectEl = newItemDiv.querySelector(".edit-drink-select");
  const priceEl = newItemDiv.querySelector(".edit-price");
  const qtyEl = newItemDiv.querySelector(".edit-qty");
  const idx = currentEditItems.length - 1;
  
  selectEl.addEventListener("change", (e) => {
    const [name, price] = e.target.value.split("|");
    if (name) {
      priceEl.value = price;
      currentEditItems[idx].name = name;
      currentEditItems[idx].price = parseInt(price) || 0;
    }
  });
  
  qtyEl.addEventListener("change", (e) => {
    currentEditItems[idx].qty = parseInt(e.target.value) || 1;
  });
  
  priceEl.addEventListener("change", (e) => {
    currentEditItems[idx].price = parseInt(e.target.value) || 0;
  });
});

/* ---------- INIT ---------- */
/* ---------- INIT (only if page is loaded) ---------- */
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    renderAll();
    // Start polling so cashier sees incoming orders automatically
    startCashierPolling();
  });
} else {
  renderAll();
  startCashierPolling();
}