# CULTIVA - Dashboard Troubleshooting Guide

## Quick Diagnostics

Visit: **http://localhost/CULTIVA/diagnostics.html**

This page will automatically check:
- ✓ Database connection
- ✓ Inventory table structure (type column)
- ✓ Sample data in database
- ✓ All API endpoints

## If Dashboard Still Not Working

### Option 1: Database Issues
**Problem**: "Type column not found" or "No data"

**Solution**: 
1. Go to: **http://localhost/CULTIVA/fix-database.html**
2. Copy the SQL code
3. Paste it in phpMyAdmin → SQL tab → Execute
4. Refresh the diagnostics page

### Option 2: Server Not Running
**Problem**: "Cannot connect to database"

**Solution**:
1. Start your server (XAMPP/WAMP)
2. Make sure MySQL is running
3. Check that PHP is enabled

### Option 3: Clear Browser Cache
Sometimes old data is cached:
1. Press **Ctrl + Shift + Delete**
2. Clear "All time" data
3. Refresh the page

## Working URLs

| Page | URL |
|------|-----|
| Admin Dashboard | http://localhost/CULTIVA/dashboard/admin.html |
| Cashier Dashboard | http://localhost/CULTIVA/dashboard/cashier.html |
| Diagnostics | http://localhost/CULTIVA/diagnostics.html |
| Database Fix | http://localhost/CULTIVA/fix-database.html |
| Login | http://localhost/CULTIVA/auth.html |

## Inventory Management Features

Once admin dashboard is working:

1. **Login** as admin user
2. Click **Inventory Management** tab
3. **Add items**: Click "Add Item" button
4. **Filter by category**: Use dropdown or tabs (Beverages, Utensils, etc.)
5. **Edit items**: Click "Edit" button
6. **Delete items**: Click "Delete" button

## Common Issues & Fixes

### Issue: "Cannot GET /CULTIVA/api/inventory.php"
- Make sure your project is in: `C:\xampp\htdocs\CULTIVA\` (or your server root)
- Restart the web server
- Check PHP is enabled

### Issue: Dashboard shows empty/error
- Run diagnostics page to identify the exact issue
- Check browser console (F12) for errors
- Check server logs in phpMyAdmin

### Issue: Inventory items don't save
- Check database has `type` column (run fix-database.html)
- Verify `unit_price` is DECIMAL format
- Check API response in console

## Files Modified for This Fix

1. **js/dashboard.js** - Added error handling and null checks
2. **diagnostics.html** - Complete diagnostic tool
3. **fix-database.html** - SQL migration tool

## Next Steps

1. Visit **diagnostics.html** to identify issues
2. Use **fix-database.html** if database needs fixing
3. Go to **admin dashboard** once everything is working
