# Database Migration Instructions

## Problem
The inventory table was missing the `type` column needed for category support in the admin dashboard.

## Solution
Follow these steps to update your database:

### Option 1: Using the Setup Page (Recommended)
1. Open your browser and go to: `http://localhost/CULTIVA/setup.html`
2. Click **"Run Migration"** button
3. Wait for the success message
4. Click **"Verify Setup"** to confirm everything is working
5. Click the **"Go to Admin Dashboard"** link

### Option 2: Manual SQL Update
If the setup page doesn't work, run this in phpMyAdmin or MySQL CLI:

```sql
-- Add type column if it doesn't exist
ALTER TABLE inventory ADD COLUMN type VARCHAR(100) NOT NULL DEFAULT 'other' AFTER item_name;

-- Add index for better query performance
ALTER TABLE inventory ADD INDEX (type);

-- Update unit_price column to use decimal (optional but recommended)
ALTER TABLE inventory MODIFY COLUMN unit_price DECIMAL(10, 2) NOT NULL DEFAULT 0.00;
```

### Option 3: Recreate the Table
Drop and recreate the table using the updated SQL file:

1. Run the SQL from `db/inventory_table.sql` in phpMyAdmin
2. This will create the table with the correct structure and sample data

## After Migration
Once the migration is complete:
- All inventory items will support categories (beverages, utensils, condiments, pastries, other)
- The inventory dashboard will display items grouped by type
- Adding new items will let you select a category
- Category filter tabs will appear in the inventory management section

## Verification
To verify the migration worked:
1. Go to Admin Dashboard → Inventory
2. Look for category tabs at the top (All, Beverages, Utensils, etc.)
3. Try adding a new inventory item and selecting a category
4. The item should appear with the correct category tag
