# CULTIVA ☕ — Premium Coffee Shop POS System

A modern, responsive **Point-of-Sale (POS) and Order Management System** designed for CULTIVA coffee shop. This web-based application enables customers to order through a digital menu and allows cashiers and baristas to manage orders from intake through completion.

---

## 📋 System Overview

**CULTIVA** is a full-stack web application with three primary interfaces:

1. **Customer Menu** (`index.html` / `menu.html`)
   - Browse and order drinks and add-ons
   - Add items to cart with quantities
   - Submit orders to the cashier system
   - View order status in real-time

2. **Cashier Dashboard** (`dashboard/cashier.html`)
   - View incoming orders (New → Pending → Preparing → Completed)
   - Acknowledge or reject orders
   - Record payment and calculate change
   - Edit order items (add/remove/modify)
   - Print or view receipts

3. **Admin Dashboard** (`dashboard/admin.html`)
   - User role management (cashier, barista, admin)
   - Inventory tracking
   - Sales analytics & top-selling items
   - System administration and maintenance

---

## 🏗️ Architecture

### Frontend
- **HTML5** for semantic markup
- **CSS3** for responsive design (mobile-first, supports desktop/tablet/mobile)
- **Vanilla JavaScript** (no frameworks) for lightweight performance
  - `js/main.js` — Shared utilities and helpers
  - `js/auth.js` — Authentication & session management
  - `js/dashboard.js` — Admin dashboard logic
  - `js/dashboard.cashier.js` — Cashier dashboard logic

### Backend
- **PHP 7.4+** for server-side logic
- **MySQL** for data persistence
- RESTful JSON API endpoints in `api/` folder

### Database
- Single MySQL database: `if0_40597167_cultiva_db`
- Core tables: `users`, `orders`, `order_items`, `menu_categories`, `inventory`
- Schema defined in `db/inventory_table.sql`

---

## 🗂️ Project Structure

```
Cultiva/
├── index.html                 # Landing/menu page (customer-facing)
├── menu.html                  # Shopping cart & order interface
├── auth.html                  # Login/registration page
├── dashboard/
│   ├── admin.html            # Admin dashboard
│   ├── cashier.html          # Cashier dashboard
│   └── users.html            # User management (admin)
├── css/
│   ├── style.css             # Main stylesheet
│   ├── dashboard.css         # Shared dashboard styles
│   └── images/               # Brand assets
├── js/
│   ├── main.js               # Shared utilities (API base, helpers)
│   ├── auth.js               # Login, registration, session
│   ├── dashboard.js          # Admin features
│   └── dashboard.cashier.js  # Cashier order & payment flow
├── api/
│   ├── db.php                # Database connection (reads env vars or defaults)
│   ├── ping_db.php           # Test database connectivity
│   ├── login.php             # User authentication
│   ├── register.php          # New user registration
│   ├── get_orders.php        # Fetch all orders (filtered by status)
│   ├── save_order.php        # Create new customer order
│   ├── update_order_status.php    # Move order through workflow
│   ├── edit_order_items.php       # Modify items in an order
│   ├── record_payment.php         # Record payment & calculate change
│   ├── get_users.php             # Admin user list
│   ├── update_user_role.php      # Assign roles (admin, cashier, barista)
│   ├── delete_user.php           # Remove users
│   ├── delete_order.php          # Remove orders
│   ├── get_top_items.php         # Sales analytics
│   ├── inventory.php             # Inventory management
│   ├── reset_inventory.php       # Reset stock to defaults
│   ├── migrate_inventory.php     # Data migration helper
│   └── fix_categories.php        # Repair corrupted menu categories
├── db/
│   └── inventory_table.sql   # Database schema & sample data
├── cultiva-cashier-fix/      # Alternate/legacy cashier interface (backup)
├── README.md                 # This file
├── TESTING.md                # Test scenarios & validation steps
├── TROUBLESHOOTING.md        # Common issues & solutions
├── MIGRATION_GUIDE.md        # Data import/export instructions
└── ADMIN_IMPROVEMENTS.md     # Planned enhancements

```

---

## 🚀 Getting Started

### Local Development (XAMPP)

1. **Clone/Place Project**
   ```powershell
   # Copy Cultiva/ folder to C:\xampp\htdocs\
   # Folder structure: C:\xampp\htdocs\Cultiva\
   ```

2. **Start XAMPP Services**
   - Open XAMPP Control Panel
   - Start **Apache** and **MySQL**

3. **Create Local Database**
   - Open phpMyAdmin: `http://localhost/phpmyadmin/`
   - Create database: `cultiva_db`
   - Import schema: `db/inventory_table.sql`
     - phpMyAdmin → Select `cultiva_db` → Import → Choose file → Go

4. **Access the Application**
   - Customer Menu: `http://localhost/Cultiva/`
   - Login: `http://localhost/Cultiva/auth.html`
   - Cashier Dashboard: `http://localhost/Cultiva/dashboard/cashier.html` (login as cashier)
   - Admin Dashboard: `http://localhost/Cultiva/dashboard/admin.html` (login as admin)

### Test Credentials
- **Admin** — Username: `admin`, Password: `admin123` (or set during initial registration)
- **Cashier** — Username: `cashier`, Password: `cashier123`
- Create additional users via Admin Dashboard

---

## 🌐 Deployment (InfinityFree & Production)

### Database Setup
1. Access your InfinityFree hosting control panel.
2. Open **phpMyAdmin** (usually linked in control panel).
3. Create a database named `if0_40597167_cultiva_db` (or as provided).
4. Import `db/inventory_table.sql`:
   - phpMyAdmin → Select database → Import → Upload `inventory_table.sql` → Execute

### Upload Files
1. Use **FTP** (credentials from InfinityFree control panel) or the **File Manager** in the hosting panel.
2. Upload entire `Cultiva/` folder to the public web root.
3. Ensure folder structure is preserved.

### Database Configuration
The system automatically uses production credentials if set. To override:
- **Option A (Production-Ready):** Credentials are embedded in `api/db.php` as defaults.
- **Option B (Secure):** Use environment variables in your hosting control panel:
  ```
  DB_HOST=sql112.infinityfree.com
  DB_USER=if0_40597167
  DB_PASS=QYCT0JOLgL
  DB_NAME=if0_40597167_cultiva_db
  ```
  Then `api/db.php` will automatically read them.

### Verify Deployment
```powershell
# Test connectivity
Invoke-RestMethod 'http://your-domain/Cultiva/api/ping_db.php'

# Should return: {"status":"success","message":"Database connected"}
```

---

## 📱 User Roles & Workflows

### Customer
1. Browse menu items by category (Espresso, Frappe, Milkshake, Tea, etc.)
2. Add items to cart with quantity
3. Click "Send to Cashier" to submit order
4. Receive order code (e.g., `ORD-20251205-001`)
5. Track order status in real-time

### Cashier
1. **View Pending Orders:** New orders arrive automatically (5-second polling)
2. **Acknowledge Order:** Click "✓ Acknowledge" or "✗ Reject"
3. **Record Payment:** Enter amount paid, confirm change calculation
4. **Move to Preparing:** Order automatically moves to "Preparing" after payment
5. **Complete Order:** Click "✓ Complete" when ready for pickup
6. **View Receipt:** Click "📋 View Receipt" to see order details and payment info
7. **Edit Order:** Modify items (name, qty, price) before payment if needed

### Admin
1. **Manage Users:** Add/remove/update roles (Admin, Cashier, Barista)
2. **View Analytics:** See top-selling items and sales trends
3. **Inventory Management:** Track stock levels and adjust quantities
4. **System Health:** Run diagnostic checks (ping database, verify connectivity)
5. **Maintenance:** Reset inventory, fix corrupted data, migrate records

---

## 🔐 Authentication & Security

- **Session-based:** Users log in and receive a session token stored in `localStorage`.
- **Role-based Access Control (RBAC):** Different dashboards for admin, cashier, and customer roles.
- **Password Hashing:** Passwords are hashed with PHP's `password_hash()` (bcrypt, cost 10).
- **JSON API:** All communication via JSON with proper Content-Type headers.
- **Error Handling:** Database errors do not expose credentials or internal structure; generic messages are shown to users.

---

## 📊 Database Schema

### `users` Table
```sql
id (PK) | username | password (hashed) | email | role | created_at
```

### `orders` Table
```sql
id (PK) | code (unique) | status | date | notes
```
Statuses: `new`, `pending`, `preparing`, `completed`, `rejected`

### `order_items` Table
```sql
id (PK) | order_id (FK) | name | qty | price
```

### `menu_categories` Table
```sql
id (PK) | category_name
```

### `inventory` Table
```sql
id (PK) | item_name | qty_on_hand | reorder_level
```

---

## 🔄 Order Workflow

```
Customer → Menu → Cart → Submit Order
                              ↓
                    Cashier Dashboard (NEW)
                    ✓ Acknowledge / ✗ Reject
                              ↓
                         PENDING (Payment)
                    $ Record Payment & Change
                              ↓
                         PREPARING (Barista)
                    ✓ Complete when done
                              ↓
                        COMPLETED
                      📋 View Receipt
```

---

## 📋 Key Features

### Menu Management
- **Categories:** Espresso, Frappe, Milkshake, Tea, Non-Coffee, Add-ons
- **Pricing:** Dynamic pricing per item, add-on pricing
- **Customization:** Customers can modify drinks (add shots, syrups, toppings)

### Payment Processing
- **Manual Payment Entry:** Cashier enters amount received
- **Change Calculation:** Automatic change calculation with validation
- **Payment Confirmation:** Records amount paid, change, and timestamp

### Reporting & Analytics
- **Top Selling Items:** Dashboard shows best-performing menu items
- **Order History:** View all orders with status, items, and payment info
- **Date Filtering:** Filter orders by date range (admin only)

### Order Editing
- Add/remove items from orders before payment
- Modify quantities and prices on the fly
- Real-time total recalculation

---

## ⚙️ Configuration & Environment

### API Base URL
The system dynamically computes the API base URL by detecting the project root (first segment in the URL path). For example:
- `http://localhost/Cultiva/` → API base: `http://localhost/Cultiva/api`
- `http://your-domain/Cultiva/` → API base: `http://your-domain/Cultiva/api`

You can override this by setting `window.SITE_API_BASE` before loading dashboard scripts.

### Database Connection
- **Config File:** `api/db.php`
- **Fallback:** Uses InfinityFree credentials if environment variables are not set
- **Character Set:** UTF-8 MB4 (supports emoji and special characters)

---

## 🧪 Testing & Validation

See `TESTING.md` for:
- Manual test scenarios (customer flow, cashier workflow, admin tasks)
- Endpoint testing (curl examples for all API routes)
- Edge case validation (invalid payment, missing items, etc.)

---

## 🐛 Troubleshooting

Common issues and solutions are documented in `TROUBLESHOOTING.md`:
- Database connection errors
- CORS issues
- Missing menu items
- Payment calculation errors
- Session/authentication problems

---

## 📚 Additional Documentation

- **MIGRATION_GUIDE.md** — Import/export data, migrate from existing systems
- **ADMIN_IMPROVEMENTS.md** — Future enhancements and roadmap
- **TESTING.md** — Full test scenarios and validation procedures

---

## 📞 Support & Contact

For questions or issues:
1. Check `TROUBLESHOOTING.md` for common problems
2. Review `TESTING.md` for validation steps
3. Check browser console for JavaScript errors
4. Verify database connectivity: `http://your-domain/Cultiva/api/ping_db.php`

---

## 📄 License & Credits

**CULTIVA** — Premium Coffee Shop Experience
© 2025 — All Rights Reserved

System built with vanilla HTML5, CSS3, JavaScript, and PHP + MySQL.

---

## 🎯 Quick Reference

| Action | URL |
|--------|-----|
| Customer Menu | `/` or `/index.html` |
| Login | `/auth.html` |
| Cashier Dashboard | `/dashboard/cashier.html` |
| Admin Dashboard | `/dashboard/admin.html` |
| API Test | `/api/ping_db.php` |
| Orders API | `/api/get_orders.php` |

---

**Last Updated:** December 5, 2025
**Version:** 1.0 (Production Ready)
